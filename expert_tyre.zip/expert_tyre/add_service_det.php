<?php
include "db_config.php";
$service_id=$_POST["service_id"];
$vehicle=$_POST["vehicle"];
$cost=$_POST["cost"];
$tax_pc=$_POST["tax_pc"];
$tax_pc_sgst=$_POST["tax_pc_sgst"];
$total=$_POST["total"];
$discount=$_POST["discount"];
$tax=$_POST["tax"];
$tax_sgst=$_POST["tax_sgst"];
$qty=$_POST["qty"];
$trans_id=$_POST["trans_id"];
 

$sql = "SELECT ifnull(max(subtrans_id),1000001)+1 subtrans_id FROM service_trans_det where trans_id='".$trans_id."'";
$result = $conn->query($sql);

  if($row = $result->fetch_assoc()) {
	$subtrans_id=$row["subtrans_id"] ;
  }	
$sql = "insert into service_trans_det(trans_id,subtrans_id,service_id,vehicle,cost,qty,total,tax,tax_amount,active_status,created_on,created_by,tax_sgst,tax_amount_sgst,discount)values('".$trans_id."','".$subtrans_id."','".$service_id."','".$vehicle."','".$cost."','".$qty."','".$total."','".$tax_pc."','".$tax."','A',now(),'".$_SESSION["user_id"]."','".$tax_pc_sgst."','".$tax_sgst."','".$discount."')";
$result = $conn->query($sql);
$sql = "SELECT sum(total+tax_amount+tax_amount_sgst) GRAND_TOTAL FROM service_trans_det where trans_id='".$trans_id."' and active_status='A'";
$result = $conn->query($sql);
if($row = $result->fetch_assoc()) {
	$grand_total=$row["GRAND_TOTAL"] ;
  }	
  $sql = "update service_trans set trans_amount='".$grand_total."'  where trans_id='".$trans_id."'";
  $conn->query($sql);
//echo $sql;
echo $subtrans_id."~".$grand_total;
$conn->close();
?>