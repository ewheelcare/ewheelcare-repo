<!DOCTYPE html>
<html lang="en">

<head>
<?php include "header_include.php";?>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include "sidemenu.php";?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include "topmenu.php";?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                  
                    <!-- Content Row -->
                    <div class="row">
					<?php 
					$module=$_GET["param"];
					?>
					<div class="alert alert-info col-md-12" style="text-transform:uppercase;font-weight:bold;text-align:center">Master Maintenance : <?php echo $module;?></div>
<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal" id="add_opener">
  Add <?php echo $module;?>
</button>

 <div class="table-responsive">
                               <table id="myTable" class="display table table-striped" style="width:100%"></table>
							  </div>
                    </div>

                    

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
           <?php include "footer.php";?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
   <?php include "modals.php";?>
   
   
   <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title">Add <?php echo $module;?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <div class="modal-body" id="add_block">
        
     

    </div>
	 <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
		 <button type="button" class="btn btn-success" id="add_submit">Save</button>
		
       
      </div>
  </div>
</div>
</div>
  <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title">Edit <?php echo $module;?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <div class="modal-body" id="edit_block">
        
     

    </div>
	 <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
		 <button type="button" class="btn btn-success" id="edit_submit">Save</button>
		
       
      </div>
  </div>
</div>
</div>
<?php include "footer_include.php";?>

	<script src="js/jquery-3.5.1.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
<script>
function initializeDatePickers() {
    $(".date").datepicker({
        dateFormat: "yy-mm-dd"
    });
}
var addModal = new bootstrap.Modal(document.getElementById('addModal'));
	var editModal = new bootstrap.Modal(document.getElementById('editModal'));
   $(".date").datepicker({
        dateFormat: "yy-mm-dd"  // Set format to yyyy-mm-dd
      });
 $('#add_opener').on('click', function() {
      //alert('Button was clicked!');
      // You can run any function here
	
	  let module="<?php echo $module;?>";
	 $.post( "generic_form.php", {module:module})
  .done(function( data ) {
	  $("#add_block").html($.trim(data));
	    addModal.show();
initializeDatePickers();
  
  });
    });

$('#add_submit').on('click', function(e) {
  e.preventDefault(); // Prevent normal form submission

  const form = $("#generic_form");
  const url = form.attr('action');
  const formData = form.serialize();

  $.post(url, formData)
    .done(function(response) {
      console.log('✅ Server response:', response);
	  console.log(response);
      alert(response);
	  location.reload();
    })
    .fail(function(xhr) {
      console.error('❌ Error:', xhr.responseText);
      alert('Something went wrong.');
    });
});

$('#edit_submit').on('click', function(e) {
  e.preventDefault(); // Prevent normal form submission

  const form = $("#generic_form_update");
  const url = form.attr('action');
  const formData = form.serialize();

  $.post(url, formData)
    .done(function(response) {
      console.log('✅ Server response:', response);
	  console.log(response);
      alert(response);
	  location.reload();
    })
    .fail(function(xhr) {
      console.error('❌ Error:', xhr.responseText);
      alert('Something went wrong.');
    });
});
$(document).ready(function() {
	 let module="<?php echo $module;?>"; 
 $.post( "generic_fetch.php", { module: module })
  .done(function( data ) {
	  let jsonData=(data);
	 if (jsonData.length === 0) {
    $('#myTable').html("<p>No data available</p>");
    return;
  }

  // 1. Generate columns dynamically based on keys of first object
  const columns = Object.keys(jsonData[0]).map(key => ({
    title: key,   // column header
    data: key     // property name to pull from
  }));

  // 2. Initialize DataTable with dynamic columns and data
  $('#myTable').DataTable({
    data: jsonData,
    columns: columns
  });
  });
});

function callFunction(id) {
     let module="<?php echo $module;?>";
	 
	 $.post( "generic_form_update.php", {module:module,id:id})
  .done(function( data ) {
	  $("#edit_block").html($.trim(data));

	    editModal.show();
			  initializeDatePickers();

  
  });
}
function delFunction(id) {
     let module="<?php echo $module;?>";
	 var r=confirm("Are you sure you want to delete");
	 if(r){
	 $.post( "generic_form_delete.php", {module:module,id:id})
  .done(function( data ) {
	location.reload();
  
  });
	 }
}
</script>


</script>

  

</body>

</html>