<?php
include "db_config.php";
$trans_date = $_POST["trans_date"];
$details = $_POST["details"];
$vendor = $_POST["vendor"];

$sql = "SELECT ifnull(max(trans_id),0)+1000001 trans_id FROM receipt_trans";
$result = $conn->query($sql);

  if($row = $result->fetch_assoc()) {
	$trans_id=$row["trans_id"] ;
  }	
$sql = "insert into receipt_trans(trans_id,details,vendor,trans_date,active_status)values('".$trans_id."','".$details."','".$vendor."','".$trans_date."','A')";
$result = $conn->query($sql);
//echo $sql;
echo "Receipt added Successfully";
$conn->close();
?>