<?php
include "db_config.php";
$payment_date = $_POST["payment_date"];
$nature = $_POST["nature"];
$vendor = $_POST["vendor"];
$vendor_name = $_POST["vendor_name"];
$customer = $_POST["customer"];
$customer_name = $_POST["customer_name"];
$mode = $_POST["mode"];
$account = $_POST["account"];
$amount = $_POST["amount"];
$reference = $_POST["reference"];


$sql = "SELECT ifnull(max(payment_id),1000001)+1 payment_id FROM payments";
$result = $conn->query($sql);

  if($row = $result->fetch_assoc()) {
	$payment_id=$row["payment_id"] ;
  }	
$sql = "INSERT INTO payments (
            payment_id, payment_date, nature, vendor, vendor_name,
            customer, customer_name, mode, account,
            amount, reference, active_status, shop_id, created_on
        ) VALUES (
            '$payment_id', '$payment_date', '$nature', '$vendor', '$vendor_name',
            '$customer', '$customer_name', '$mode', '$account', $amount,
            '$reference', 'A', '" . $_COOKIE["shop"] . "', NOW()
        )";
$result = $conn->query($sql);
echo $sql;
while($amount>0){
	if($nature =="DEBIT"){
	$select_receipt_trans = "SELECT trans_id,pending FROM receipt_trans where vendor='".$vendor."' and pending>0 order by trans_date"	;
	$result = $conn->query($select_receipt_trans);

 if(($row = $result->fetch_assoc())  && $amount>0) {
	$pending=$row["pending"] ;
	$trans_id=$row["trans_id"] ;
	$amount_settled=0;
	if($amount>$pending){
		$amount_settled=$pending;
		$pending=0;
		
	}else{
		$pending = $pending-$amount;
		$amount_settled=$amount;
	}
	$update_receipt_trans = "update receipt_trans set pending=".$pending ." where trans_id='".$trans_id."'"	;
	$conn->query($update_receipt_trans);
	$insert_pay_track = "insert into pay_track(payment_id,amount_settled,trans_id,mode) values('".$payment_id."','".$amount_settled."','".$trans_id."','RECEIPT')";
	$conn->query($insert_pay_track);
	$amount=$amount-$row["pending"];
  }	
		
	}else{
	$select_receipt_trans = "SELECT trans_id,pending FROM service_trans where customer='".$customer."' and pending>0 order by trans_date"	;
	$result = $conn->query($select_receipt_trans);

 if(($row = $result->fetch_assoc()) && $amount>0 ) {
	$pending=$row["pending"] ;
	$trans_id=$row["trans_id"] ;
	$amount_settled=0;
	if($amount>$pending){
		$amount_settled=$pending;
		$pending=0;
		
	}else{
		$pending = $pending-$amount;
		$amount_settled=$amount;
	}
	$update_receipt_trans = "update service_trans set pending=".$pending ." where trans_id='".$trans_id."'"	;
	$conn->query($update_receipt_trans);
	$insert_pay_track = "insert into pay_track(payment_id,amount_settled,trans_id,mode) values('".$payment_id."','".$amount_settled."','".$trans_id."','service')";
	
	$conn->query($insert_pay_track);
	$amount=$amount-$row["pending"];
  }		
		
	}
	
	
}
echo "Receipt added Successfully";
$conn->close();
?>