<?php
include "db_config.php";
$address = $_POST["address"];
$customer_id = $_POST["customer_id"];



$sql = "insert into customer_address(customer_id,address)values('".$customer_id."','".$address."')";
$result = $conn->query($sql);
//echo $sql;
echo "Address added Successfully";
$conn->close();
?>