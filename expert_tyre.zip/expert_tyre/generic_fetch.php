<?php
include "db_config.php";
$module=$_POST["module"];

$pk=$module."_id";
$form_name=$module."_module";
$module = $module."_layout.json";
$json = file_get_contents($module);


// Decode JSON into PHP array
$fields = json_decode($json, true);

$selectFields = [];
$tables = [];
$joins = [];

// Track base table (first one assumed as main)
$baseTable = null;

foreach ($fields as $fieldData) {
    $field = $fieldData['field'];
    $ref = $fieldData['ref'];
    $condition = $fieldData['condition'] ?? null;

    // Add field to SELECT
    if (!in_array($field, $selectFields)) {
        $selectFields[] = $field;
    }

    // Set base table (first encountered)
    if (!$baseTable) {
        $baseTable = $ref;
        $tables[$ref] = 'base';
        continue;
    }

    // Handle JOINs
    if ($ref !== $baseTable && $condition) {
        // Prevent duplicate joins
        if (!isset($tables[$ref])) {
            $joins[] = "JOIN $ref ON $condition";
            $tables[$ref] = 'joined';
        }
    }
}

// Build the final SQL
$sql = "SELECT $pk," . implode(", ", $selectFields) . " FROM $baseTable ";

if (!empty($joins)) {
    $sql .= implode(" ", $joins);
}

//echo $sql;
$result =  $conn->query($sql);

// 4. Initialize array
$data = [];

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
		
		 
            $row['action_button'] = '<button class="btn btn-sm btn-warning" onclick="callFunction(' . $row[$pk] . ')">Edit</button>&nbsp;&nbsp;<button class="btn btn-sm btn-danger" onclick="delFunction(' . $row[$pk] . ')">Delete</button>';
       if($_POST["module"]=="customer"){
		  $row['action_button'].='&nbsp;<a class="btn btn-sm btn-warning" href="attach_gst.php?customer_id=' . $row[$pk] . '">Attach GST</a>&nbsp;<a class="btn btn-sm btn-primary" href="attach_address.php?customer_id=' . $row[$pk] . '">Attach Address</a>' ; 
		   
	   }
        $data[] = $row;  // Each row is an associative array
    }
}

// 5. Convert to JSON
$json = json_encode($data, JSON_PRETTY_PRINT);

// 6. Output (or return it)
header('Content-Type: application/json');
echo $json;

// 7. Close connection
$mysqli->close();?>