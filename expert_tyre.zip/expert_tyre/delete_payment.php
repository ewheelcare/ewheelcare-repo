<?php
include "db_config.php";
$payment_id = $_POST["payment_id"];



$sql = "update payments set active_status='Z' where payment_id='".$payment_id ."'";
$result = $conn->query($sql);

 
$select_receipt_trans = "SELECT trans_id,amount_settled,mode FROM pay_track where payment_id='".$payment_id."'"	;
$result = $conn->query($select_receipt_trans);	
while($row = $result->fetch_assoc()){
	$amount_settled=$row["amount_settled"] ;
	$trans_id=$row["trans_id"] ;
	$mode=$row["mode"] ;
	if($mode =="service"){
	$update_receipt_trans = "update service_trans set pending=pending+".$amount_settled." where trans_id='".$trans_id."'"	;
	$conn->query($update_receipt_trans);
	$insert_pay_track = "delete  from  pay_track where payment_id='".$payment_id."' and trans_id='".$trans_id."'";
	$conn->query($insert_pay_track);
	}else{
	$update_receipt_trans = "update receipt_trans set pending=pending+".$amount_settled." where trans_id='".$trans_id."'"	;
	$conn->query($update_receipt_trans);
	$insert_pay_track = "delete  from  pay_track where payment_id='".$payment_id."' and trans_id='".$trans_id."'";
	$conn->query($insert_pay_track);	
		
	}


	
}
echo "deleted Successfully";
$conn->close();
?>