<?php 
include "db_config.php";
$uid=$_POST["uid"];
$pwd=$_POST["pwd"];
$shop=$_POST["shop"];
$shop_name=$_POST["shop_name"];
$response_obj=[];
$sql="SELECT user_name,user_role FROM expert_login l,expert_login_role r where l.user_id='".$uid."' and l.user_pwd='".$pwd."' and l.user_id=r.user_id";
$result = $conn->query($sql);

if ($row = $result->fetch_assoc()) {
do{$user_name = addslashes($row['user_name']);
$user_role = addslashes($row['user_role']);
$_SESSION["user_name"]=$user_name;
$_SESSION[$user_role]="Y";
$_SESSION["user_id"]=$uid;
setcookie("user_id", $uid, time() + 3600, "/");
setcookie($user_role, "Y", time() + 3600, "/");
setcookie("user_name", $user_name, time() + 3600, "/");
setcookie("shop", $shop, time() + 3600, "/");
setcookie("shop_name",$shop_name, time() + 3600, "/");
$response_obj["status"]="S";}while($row = $result->fetch_assoc());
	$response_obj["message"]="Login Successful";	
}else{
	$response_obj["status"]="F";
	$response_obj["message"]="Invalid Login Credentials";	
}
print_r( json_encode($response_obj));
?>