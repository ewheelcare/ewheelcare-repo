<!DOCTYPE html>
<html lang="en">

<head>
<?php include "header_include.php";
include "db_config.php";
?>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include "sidemenu.php";?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include "topmenu.php";?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                  
                    <!-- Content Row -->
                    <div class="row">
					<form action="#" method="post">
					<table>
					<tr>
					<td><select class="form-control" id="item" name="item">
					<option value="">---SELECT----</option>
					<?php  $sql="SELECT item_id,item_name,item_description,cost,tax_pc FROM item order by 1";
					$result = $conn->query($sql);

while ($row1 = $result->fetch_assoc()) {?>
<option value="<?php echo $row1['item_id'];?>~<?php echo $row1['item_name'];?>"><?php echo $row1['item_name'];?>(<?php echo  $row1['item_description'];?>,Cost: <?php echo $row1['cost'];?>, Tax (%): <?php echo $row1['tax_pc'];?>)</option>
<?php }?>
					</select></td>
					<td><input type="submit" class="button btn-sm btn-primary"/></td>
					</tr>
					</table>
					</form>
					<div class="row">
			<?php
			
			$item=explode("~",$_POST["item"])[0];
			$item_name=explode("~",$_POST["item"])[1];?>
			<div class="alert alert-warning col-md-12"><?php echo $item_name;?></div>
			<?php $sql = "SELECT s.shop_id,s.shop_name,ifnull(inv.qty,0) qty FROM  shop s left outer join (select i.qty, i.shop_id from inventory i where i.item_id='".$item."') inv on inv.shop_id=s.shop_id";
//echo $sql;
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()) {
	
$shop_id= $row["shop_id"];
$shop_name=$row["shop_name"];
$qty=$row["qty"];?>
<div class="col-md-3 alert alert-info">
<h4><?php echo $shop_name;?></h4>
Stock : <?php echo $qty;?><br>
<input class="form-control" id="draw_<?php echo $shop_id;?>" style="display:none" onkeyup="set_storage()" type="number" max="<?php echo $qty;?>" min="0">
<button class="brn btn-sm btn-danger" onclick="open_draw_box('<?php echo $shop_id;?>')">Draw</button>
<button class="brn btn-sm btn-success" onclick="deposit_box('<?php echo $shop_id;?>')">Deposit</button>
</div>

<?php }


?>			
</div>
                    

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
           <?php include "footer.php";?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
   <?php include "modals.php";?>
   
   
   
<?php include "footer_include.php";?>
	<script src="js/jquery-3.5.1.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
	 <script src="js/demo/datatables-demo.js"></script>

<script>
let from_shop="";
let from_qty="";
function open_draw_box(shop){
let sel = "draw_"+shop;
from_shop = shop;
document.getElementById(sel).style.display="";	
}
function set_storage(){
	let sel = "draw_"+from_shop;
	from_qty = document.getElementById(sel).value;
}

function deposit_box(shop){
let to_shop=shop;
 $.post("draw_deposit.php",
  {
    
    from_shop: from_shop,
	from_qty:from_qty,
	to_shop:to_shop,
	item:"<?php echo $item;?>"
	
	
  },
  function(data, status){
    alert($.trim(data));
	location.reload();
  });
}




</script>

  

</body>

</html>