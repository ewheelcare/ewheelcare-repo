<?php
include "db_config.php";

// Collect and sanitize POST data
$trans_date = $_POST["trans_date"] ?? '';
$customer = $_POST["customer"] ?? '';
$gst = $_POST["gst"] ?? '';
$vehicle_no = $_POST["vehicle_no"] ?? '';  // Fixed: It was wrongly assigned from 'trans_date'
$vehicle_model = $_POST["vehicle_model"] ?? '';
$no_of_wheels = $_POST["no_of_wheels"] ?? '';
$vehicle = $_POST["vehicle"] ?? '';
$company_name = $_POST["company_name"] ?? '';
$customer_name = $_POST["customer_name"] ?? '';
$customer_address = $_POST["customer_address"] ?? '';
$customer_gst = $_POST["customer_gst"] ?? '';
$vehicle_odometer = $_POST["vehicle_odometer"] ?? '0'; // Added this as it was used but not defined

// Get new transaction ID
$sql = "SELECT IFNULL(MAX(trans_id), 1000000) + 1  AS trans_id FROM service_trans";
$result = $conn->query($sql);
$trans_id = 1000001;

if ($result && $row = $result->fetch_assoc()) {
    $trans_id = $row["trans_id"];
}

// Prepare insert statement
$sql = "INSERT INTO service_trans (
    trans_id, vehicle_no, customer, trans_date, active_status, gst, vehicle_model, 
    no_of_wheels, vehicle_odometer, vehicle, company_name, customer_name, 
    CUSTOMER_ADDRESS, CUSTOMER_GST
) VALUES (?, ?, ?, ?, 'A', ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}

// Bind parameters to the prepared statement
$stmt->bind_param(
    "issssssisssss",
    $trans_id,
    $vehicle_no,
    $customer,
    $trans_date,
    $gst,
    $vehicle_model,
    $no_of_wheels,
    $vehicle_odometer,
    $vehicle,
    $company_name,
    $customer_name,
    $customer_address,
    $customer_gst
);

// Execute and check result
if ($stmt->execute()) {
    echo $trans_id;
} else {
    echo "Insert failed: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
