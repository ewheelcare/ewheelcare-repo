<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
                <div class="sidebar-brand-icon rotate-n-15">
                   <i class="fas fa-cog"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Expert <sup>Tyre</sup></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
			<?php if(isset($_COOKIE["user_id"])){?>
			<?php if(isset($_COOKIE["DASHBOARD"]) || isset($_COOKIE["SA"])){?>
            <li class="nav-item active">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>
			<?php }?>
            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Interface
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
			<?php if(isset($_COOKIE["MASTER"]) || isset($_COOKIE["SA"])){?>
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-cog"></i>
                    <span>Configure</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Master Maintenance:</h6>
                        <a class="collapse-item" href="module.php?param=customer">Customer</a>
                        <a class="collapse-item" href="module.php?param=vendor">Vendor</a>
						  <a class="collapse-item" href="module.php?param=vehicle">Vehicle</a>
                        <a class="collapse-item" href="module.php?param=location">Location</a>
						<a class="collapse-item" href="module.php?param=shop">Shop</a>
						<a class="collapse-item" href="module.php?param=storagelocation">Storage Location</a>
						<a class="collapse-item" href="module.php?param=tyre_type">Tyre types</a>
						<a class="collapse-item" href="module.php?param=item">Item</a>
						<a class="collapse-item" href="module.php?param=service">Service</a>
						<a class="collapse-item" href="module.php?param=company">Company</a>
						<a class="collapse-item" href="module.php?param=crm">CRM</a>
						<a class="collapse-item" href="module.php?param=paytype">Pay Type</a>
						<a class="collapse-item" href="module.php?param=account">Account</a>
                    </div>
                </div>
            </li>
			<?php }?>

            <!-- Nav Item - Utilities Collapse Menu -->
			<?php if(isset($_COOKIE["ENTRY"]) || isset($_COOKIE["SA"])){?>
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities"
                    aria-expanded="true" aria-controls="collapseUtilities">
                    <i class="fas fa-fw fa-wrench"></i>
                    <span>Utilities</span>
                </a>
                <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Custom Utilities:</h6>
                        <a class="collapse-item" href="receipt.php">Receipts</a>
                        <a class="collapse-item" href="sales.php">Sales</a>
						 <a class="collapse-item" href="go_for_services.php?GSN=Y">Service (GST)</a>
						  <a class="collapse-item" href="go_for_services.php?GSN=N">Service (Non GST)</a>
						
						
                         <a class="collapse-item" href="payments.php">Payments</a>
                    </div>
                </div>
            </li>
			<?php }?>
            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
			<?php if(isset($_COOKIE["REPORT"]) || isset($_COOKIE["SA"])){?>
            <div class="sidebar-heading">
                Reports
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages"
                    aria-expanded="true" aria-controls="collapsePages">
                    <i class="fas fa-fw fa-folder"></i>
                    <span>Reports</span>
                </a>
                <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Reports</h6>
                        <a class="collapse-item" href="report_sales.php">Sales</a>
                        <a class="collapse-item" href="report_service.php">Service</a>
                        <a class="collapse-item" href="report_receipt.php">Receipt</a>
						 <a class="collapse-item" href="report_payment.php">Payment</a>
						<a class="collapse-item" href="inventory_report.php">Inventory Report</a>
						<a class="collapse-item" href="profit_analysis.php">Profit Analysis</a>
                        <div class="collapse-divider"></div>
                        <h6 class="collapse-header">Ageing</h6>
                        <a class="collapse-item" href="report_sales_ageing.php">Sales</a>
                        <a class="collapse-item" href="report_service_ageing.php">Service</a>
                    </div>
                </div>
            </li>
			<?php }?>
            <!-- Nav Item - Charts -->
			<?php if(isset($_COOKIE["INVENTORY"]) || isset($_COOKIE["SA"])){?>
            <li class="nav-item">
                <a class="nav-link" href="transfer_inventory.php">
                    <i class="fas fa-fw fa-chart-area"></i>
                    <span>Stock Transfer</span></a>
            </li>
<?php }?>
            <!-- Nav Item - Tables -->
			<?php if(isset($_COOKIE["SA"])){?>
            <li class="nav-item">
                <a class="nav-link" href="user.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>User Management</span></a>
            </li>
<?php }?>
            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

            <!-- Sidebar Message -->
          <!--  <div class="sidebar-card d-none d-lg-flex">
                <img class="sidebar-card-illustration mb-2" src="img/undraw_rocket.svg" alt="...">
                <p class="text-center mb-2"><strong>SB Admin Pro</strong> is packed with premium features, components, and more!</p>
                <a class="btn btn-success btn-sm" href="https://startbootstrap.com/theme/sb-admin-pro">Upgrade to Pro!</a>
            </div>-->
			<?php }?>
        </ul>