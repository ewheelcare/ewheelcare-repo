<?php
include "db_config.php";
$trans_id = $_POST["trans_id"];
$details = $_POST["details"];
$vendor = $_POST["vendor"];
$trans_date = $_POST["trans_date"];
$sql = "update receipt_trans set trans_date='".$trans_date."',details='".$details."',vendor='".$vendor."' where trans_id='".$trans_id."'";
$result = $conn->query($sql);
//echo $sql;
echo "Receipt updated Successfully";
$conn->close();
?>