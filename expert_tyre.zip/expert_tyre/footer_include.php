 <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="js/popper.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
 <!--   <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
  <!--  <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>-->
	<script>
	var loginModal = new bootstrap.Modal(document.getElementById('loginModal'));
	const errorModal = new bootstrap.Modal(document.getElementById('errorModal'));
	const successModal = new bootstrap.Modal(document.getElementById('successModal'));
 
	 $(document).ready(function() {
    $('#login_opener').on('click', function() {
      //alert('Button was clicked!');
      // You can run any function here
	  loginModal.show();
    });
  });
 /* $(document).ready(function() {
    $('.btn-close').on('click', function() {
       const $modal = $(this).closest('.modal')[0];
      const modalInstance = bootstrap.Modal.getOrCreateInstance($modal);
      modalInstance.hide();
    });
  });*/
 $('#successModal').on('hidden.bs.modal', function () {
  location.reload();
});
 $('#login').on('click', function() {
      let uid=$("#uid").val();
	  let pwd=$("#pwd").val();
	  let shop=$("#shop").val().split("~")[0];
	  let shop_name=$("#shop").val().split("~")[1];
	  let msg="";
//alert("===");	 
 
if(uid=="" || pwd=="" || shop=="")	{
msg = "Fill up login credentials,properly"	;
$("#error_block").html(msg);
errorModal.show();	
return false;
} 

$.post( "loginvalidate.php", { uid: $("#uid").val(), pwd: $("#pwd").val(), shop:shop,shop_name:shop_name })
  .done(function( data ) {
  //alert(data);
  let status=(JSON.parse($.trim(data))).status;
    msg=(JSON.parse($.trim(data))).message;
  if($.trim(status)=="S")
    {//msg = ( "Successfully logged in" );
	$("#success_block").html(msg);
successModal.show();
 setTimeout(() => {
      successModal.hide();
    }, 1600);	
	}
	else
	{//msg = ( "Login Failed. Please Retry" );
$("#error_block").html(msg);
errorModal.show();	
}
  }); 
    });
	
function load_shop_pic(){
	let shop_pic="img/shop/"+document.getElementById("shop").value.split("~")[0]+".jpg";
	document.getElementById("shop_pic").src=shop_pic;
	
}	
	</script>