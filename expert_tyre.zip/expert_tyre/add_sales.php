<?php
include "db_config.php";
$trans_date = $_POST["trans_date"];
$details = $_POST["details"];
$customer = $_POST["customer"];
$pending = $_POST["pending"];
$gst = $_POST["gst"];
$tally = $_POST["tally"];

$sql = "SELECT ifnull(max(trans_id),0)+1000001 trans_id FROM sales_trans";
$result = $conn->query($sql);

  if($row = $result->fetch_assoc()) {
	$trans_id=$row["trans_id"] ;
  }	
$sql = "insert into sales_trans(trans_id,details,customer,trans_date,active_status,pending,gst,tally)values('".$trans_id."','".$details."','".$customer."','".$trans_date."','A','".$pending."','".$gst."','".$tally."')";
$result = $conn->query($sql);
//echo $sql;
echo "Receipt added Successfully";
$conn->close();
?>