<?php
include "db_config.php";
$module=$_POST["module"];

$id = $_POST["id"];

$db = $module;
$pk=$module."_id";
$form_name=$module."_module";
$module = $module."_module.json";
$json = file_get_contents($module);
$data = json_decode($json, true);
$sql = "SELECT * FROM ".$db." where ".$pk."='".$id."'" ;
//echo $sql;
$result = $conn->query($sql);

// Step 5: Fetch one row
if ($row = $result->fetch_assoc()) {
    // Step 6: Convert row to JSON
    $jsonData = json_encode($row);
}
$jsonData = json_decode($jsonData, true);
//var_dump($jsonData);
$form = '';
$form .= '<form action="update_generic_form.php" method="post" id="generic_form_update">';
$form .= '<table class="table table-striped">';

if (is_array($data)) {
    foreach ($data as $entry) {
        $field = $entry["field"];
        $mode = $entry["mode"];
        $name_id = explode(".", $entry["Save_to"])[1];

        $form .= "<tr>";
        $form .= "<td>$field</td><td>";

        if ($mode == "input") {
            $regex = $entry["regex"];
			//echo $name_id."====".$jsonData[$name_id];
            $form .= "<input type='text' data-regex='$regex' class='form-control input' name='$name_id' id='$name_id' value='".$jsonData[$name_id]."'>";
        }
		 if ($mode == "date") {
            $regex = $entry["regex"];
			//echo $name_id."====".$jsonData[$name_id];
            $form .= "<input type='text'  class='form-control date' name='$name_id' id='$name_id' value='".$jsonData[$name_id]."'>";
        }

        if ($mode == "select") {
            $refers_to = $entry["input_src"]["refers_to"];
            $condition = $entry["input_src"]["condition"];
            $form .= "<select class='form-control select' data-src='$refers_to' data-condition='$condition' data-value='$jsonData[$name_id]' name='$name_id' id='$name_id'></select>";

            foreach ($entry["input_src"]["display"] as $disp_name) {
                $form .= "<input name='$disp_name' id='$disp_name' readonly data-takes-after='$name_id' class='form-control' value='".$jsonData[$name_id]."'>";
            }
        }

        if ($mode == "calculated") {
            $formula = $entry["formula"];
            $dependents = $entry["dependents"];
            $form .= "<input type='text' class='form-control calculated' id='$name_id' name='$name_id' data-formula='$formula' data-dependents='$dependents' value='".$jsonData[$field]."'>";
        }

        $form .= "</td></tr>";
		
    }

    $form .= "<tr><td colspan='2'>";
    $form .= "<input value='".$form_name."' type='hidden' name='form_name'>";
	    $form .= "<input value='".$id."' type='hidden' name='".$pk."'>";
  //  $form .= "<input type='submit' value='Go'>";
    $form .= "</td></tr>";
} else {
    $form .= "<tr><td colspan='2'>Error decoding JSON.</td></tr>";
}

$form .= "</table>";
$form .= "</form>";

echo $form;
?>

   <script src="vendor/jquery/jquery.min.js"></script>
   <script src="js/jquery-3.5.1.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script>
 $(function () {
    $(".date").datepicker({
        dateFormat: "yy-mm-dd"  // Set format to yyyy-mm-dd
      });
	  $(".edit_datepicker").datepicker({
        dateFormat: "yy-mm-dd"  // Set format to yyyy-mm-dd
      });
  });
     $(".date").datepicker({
        dateFormat: "yy-mm-dd"  // Set format to yyyy-mm-dd
      });
$('.input').on('blur', function() {
    const value = $(this).val().trim();
    const pattern = "^"+$(this).data('regex')+"$";
    const regex = new RegExp(pattern);

    if (regex.test(value)) {
        console.log('✅ Valid:', value);
        $(this).css('border', '2px solid green');
			document.getElementById("edit_submit").disabled = false;
    } else {
        console.log('❌ Invalid:', value);
        $(this).css('border', '2px solid red');
		document.getElementById("edit_submit").disabled = true;
    }
});
$('.select').on('focus', function() {
  let $select = $(this); // Store the jQuery object
  let data_src = $select.data('src');
  let data_condition = $select.data('condition');

  $.post("fetch_input.php", { data_src: data_src, data_condition: data_condition })
    .done(function(data) {
      console.log($.trim(data));
      let data_array = JSON.parse($.trim(data));
      
      $select.empty(); // Clear existing options

      data_array.forEach(object => {
        // Assuming object has fields like id and name
		const label = Object.entries(object)
  .map(([key, val]) => {
    const parts = key.split('_');
    const labelKey = parts.length > 1 ? parts[1] : key; // fallback if no "_"
    return `${labelKey}: ${val}`;
  })
  .join(', ');
        const option = $('<option></option>')
          .val(object.id || JSON.stringify(object))
		  .text(label);
          //.text(object.name || object.label || JSON.stringify(object));
          
        $select.append(option);
      });
    });
});
$('.select').on('focusout', function () {
    const name = $(this).attr('name');
    const value = JSON.parse($(this).val());
	//alert(value);
	$(`input[data-takes-after="${name}"]`).each(function () {
		let json_key = $(this).attr('name');
		console.log(json_key);
		let value_key = value[json_key];
		console.log(value_key);
		
      $(this).val(value_key); // Optional: update the value
      console.log(`Matched input for ${name}:`, this);
	  resolve(json_key);
    });
  });
  function resolve(decider){
	  var yourSubstring = decider;

var matchingElements = $('.calculated').filter(function () {
  return $(this).data('dependents')?.toString().includes(yourSubstring);
});

// Do something with the matching elements, e.g., log them
matchingElements.each(function () {
 
  console.log($(this).data('formula'));
   console.log($(this).data('dependents'));
   let vars=$(this).data('dependents').split("#");
   let parts = $(this).data('formula').toUpperCase();
   let exp="";
   let dep_ind=0;
  for(var i=0;i<parts.length;i++){
	  if(parts[i]>='A' && parts[i]<='Z'){
		  exp+=document.getElementById(vars[dep_ind++]).value;
		 // console.log(vars[dep_ind++]);
		  
	  }else{
		  exp+=parts[i];
	  }
	  
  }
  let ans=eval(exp) ;
  $(this).val(ans);
});
	  
	  
  }
</script>