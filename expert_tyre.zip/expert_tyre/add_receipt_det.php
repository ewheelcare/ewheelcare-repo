<?php
include "db_config.php";
$item_id=$_POST["item"];
$cost=$_POST["cost"];
$tax_pc=$_POST["tax_pc"];
$tax_pc_sgst=$_POST["tax_pc_sgst"];
$total=$_POST["total"];
$tax=$_POST["tax"];
$base_price=$_POST["base_price"];
$tax_sgst=$_POST["tax_sgst"];
$qty=$_POST["qty"];
$trans_id=$_POST["trans_id"];
 

$sql = "SELECT ifnull(max(subtrans_id),1000001)+1 subtrans_id FROM receipt_trans_det where trans_id='".$trans_id."'";
$result = $conn->query($sql);

  if($row = $result->fetch_assoc()) {
	$subtrans_id=$row["subtrans_id"] ;
  }	
$sql = "insert into receipt_trans_det(trans_id,subtrans_id,item_id,cost,qty,total,tax,tax_amount,tax_sgst,tax_amount_sgst,base_price,active_status,created_on,created_by)values('".$trans_id."','".$subtrans_id."','".$item_id."','".$cost."','".$qty."','".$total."','".$tax_pc."','".$tax."','".$tax_pc_sgst."','".$tax_sgst."','".$base_price."','A',now(),'".$_SESSION["user_id"]."')";
$result = $conn->query($sql);
echo $sql;
$sql = "SELECT sum(total+tax_amount+tax_amount_sgst) GRAND_TOTAL FROM receipt_trans_det where trans_id='".$trans_id."' and active_status='A'";
$result = $conn->query($sql);
if($row = $result->fetch_assoc()) {
	$grand_total=$row["GRAND_TOTAL"] ;
  }	
  $sql = "update receipt_trans set trans_amount='".$grand_total."'  where trans_id='".$trans_id."'";
  $conn->query($sql);
/*  $sql="update inventory set qty=qty+".$qty." where item_id=".$item_id." and shop_id='0'" ;
  //echo $sql;
$result = $conn->query($sql);
if ($result) {
if($conn->affected_rows<=0){
   $sql="insert into inventory (item_id,qty,shop_id) values ('".$item_id."',".$qty.",'0')";
   //echo $sql;
$result = $conn->query($sql);
}

}*/

echo "Receipt added Successfully";
$conn->close();
?>