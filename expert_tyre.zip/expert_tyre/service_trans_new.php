<!DOCTYPE html>
<html lang="en">

<head>
<?php include "header_include.php";
include "db_config.php";
?>
<style>
    .tooltip-wrapper {
    position: relative;
    display: inline-block;
    margin-bottom: 20px;
  }

  .tooltip-input {
    padding: 6px 8px;
    font-size: 14px;
    width: 100px;
  }

  .tooltip-text {
    position: absolute;
    bottom: 110%;
    left: 50%;
    transform: translateX(-50%);
    background-color: #333;
    color: #fff;
    padding: 6px 10px;
    border-radius: 4px;
    white-space: nowrap;
    font-size: 12px;
    opacity: 0;
    visibility: hidden;
    transition: opacity 0.3s;
    z-index: 1000;
  }

  .tooltip-wrapper.show .tooltip-text {
    visibility: visible;
    opacity: 1;
  }

  /* Optional arrow */
  .tooltip-text::after {
    content: "";
    position: absolute;
    top: 100%;
    left: 50%;
    margin-left: -5px;
    border-width: 5px;
    border-style: solid;
    border-color: #333 transparent transparent transparent;
  }
</style>
</style>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include "sidemenu.php";?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include "topmenu.php";?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                  
                    <!-- Content Row -->
                    <div class="row">
					<button class="btn btn-danger" id="invoice"  onclick="get_invoice()">Get Invoice</button>&nbsp;
					<button class="btn btn-primary" id="jobcard"  onclick="get_jobcard()">Get JobCard</button>
					
					<?php 
					//echo $trans_id;
					$gst = isset($_COOKIE["gst"]) ? $_COOKIE["gst"] : "";
					//echo $_COOKIE["gst"];
					//echo $gst;
					
				$trans_id=""; $trans_date=""; $details=""; $customer=""; $trans_amount=""; $pending=""; $gst=""; $tally=""; $created_by=""; $created_on=""; $modified_by=""; $modified_on=""; $active_status=""; $VEHICLE_NO=""; $VEHICLE_MODEL=""; $NO_OF_WHEELS=""; $COMPANY_NAME=""; $CUSTOMER_NAME=""; $CUSTOMER_ADDRESS=""; $CUSTOMER_GST=""; $VEHICLE_ODOMETER=""; $VEHICLE="";
	$trans_id=isset($_GET["trans_id"])?$_GET["trans_id"]:"";
					$sql="SELECT trans_id, trans_date, details, customer, trans_amount, pending, gst, tally, created_by, created_on, modified_by, modified_on, active_status, VEHICLE_NO, VEHICLE_MODEL, NO_OF_WHEELS, COMPANY_NAME, CUSTOMER_NAME, CUSTOMER_ADDRESS, CUSTOMER_GST, VEHICLE_ODOMETER, VEHICLE FROM service_trans where trans_id='".$trans_id."'";
//echo $sql;
$result = $conn->query($sql);

if ($row = $result->fetch_assoc()) {$trans_id=$row["trans_id"]; 
$trans_date=$row["trans_date"]; 
$details=$row["trans_id"]; 
 $customer=$row["customer"]; 
 $trans_amount=$row["trans_amount"]; 
 $pending=$row["pending"]; 
 $gst=$row["gst"]; 
 $tally=$row["tally"]; 
 $created_by=$row["created_by"]; 
 $created_on=$row["created_on"];  
 $modified_by=$row["modified_by"];  
 $modified_on=$row["modified_on"]; 
 $active_status=$row["active_status"]; 
 $VEHICLE_NO=$row["VEHICLE_NO"];  
 $VEHICLE_MODEL=$row["VEHICLE_MODEL"]; 
 $NO_OF_WHEELS=$row["NO_OF_WHEELS"]; 
 $COMPANY_NAME=$row["COMPANY_NAME"]; 
 $CUSTOMER_NAME=$row["CUSTOMER_NAME"]; 
 $CUSTOMER_ADDRESS=$row["CUSTOMER_ADDRESS"]; 
 $CUSTOMER_GST=$row["CUSTOMER_GST"]; 
 $VEHICLE_ODOMETER=$row["VEHICLE_ODOMETER"]; 
 $VEHICLE=$row["VEHICLE"]; 
 //echo "===";
// echo $trans_date."====". $customer."====". $CUSTOMER_NAME;
}

if(isset($gst) && $gst!=""){
	//echo "here";
}else{
	$gst = isset($_COOKIE["gst"]) ? $_COOKIE["gst"] : "";
}				
?>
<div class="col-md-12">
<div class="alert alert-warning" style="text-align:center;font-weight:bold">GST:<?PHP echo $gst;?></div><br><br>
					
<span class="alert alert-info">Vehicle Details</span>
<table class="table">
<tr><td>Date<input type="text" id="datepicker" class="form-control"></td>
<td>Trans No  <input class="form-control" readonly name="trans_id" id="trans_id" value="<?php echo $trans_id;?>"></td></tr>
<tr><td>Vehicle No <input class="form-control" name="vehicle_no" id="vehicle_no" value="<?php echo $VEHICLE_NO;?>" onblur="get_details();">
<a href="module.php?param=customer" class="btn btn-success" target="_blank">Add Customer, If not exists</a>
<a href="module.php?param=vehicle" class="btn btn-danger" target="_blank">Add Vehicle, If not exists</a>

</td>
<td>Vehicle Model <input class="form-control" name="vehicle_model" id="vehicle_model" value="<?php echo $VEHICLE_MODEL;?>"></td></tr>
<tr><td>No of Wheels <input class="form-control" name="no_of_wheels" id="no_of_wheels" value="<?php echo $NO_OF_WHEELS;?>" onblur="setwheels()"></td>
<td>Odometer <input class="form-control" name="vehicle_odometer" id="vehicle_odometer" value="<?php echo $VEHICLE_ODOMETER;?>"></td></tr>
<input class="form-control" name="vehicle" id="vehicle" value="<?php echo $VEHICLE;?>" type="hidden">
</table>
</div>
<div class="col-md-12">
<span class="alert alert-success">Customer Details</span>
<table class="table">
<tr><td>Company Name<input class="form-control" name="company_name" id="company_name" value="<?php echo $COMPANY_NAME;?>"></td>
<td>Customer Name <input class="form-control" name="customer_name" id="customer_name" value="<?php echo $CUSTOMER_NAME;?>"></td></tr>
<?php if((isset($_COOKIE["gst"]) && $_COOKIE["gst"]=="Y")||($gst=="Y")){$visibility="";}else{$visibility="hidden";}?>
<tr><td style="visibility:<?php echo $visibility;?>">GST <input class="form-control" name="customer_gst" id="customer_gst" value="<?php echo $CUSTOMER_GST;?>" list="gst_list" onfocus="get_gst()" autocomplete="off" onblur="set_gst()">
<datalist id="gst_list">
</datalist></td>
<td>Address <input class="form-control" name="customer_address" id="customer_address" value="<?php echo $CUSTOMER_ADDRESS;?>" list="address_list" onfocus="get_address()" autocomplete="off">
<datalist id="address_list">
</datalist>
<input class="form-control" name="customer" id="customer" value="<?php echo $customer;?>" type="hidden">
</td></tr></table>
</div>
<div class="col-md-12">
<?php  $sql="SELECT service_id,service_name,service_description,cost,tax_pc,tax_pc_sgst FROM service order by 1";
$result = $conn->query($sql);

while ($row1 = $result->fetch_assoc()) {?>
<button  class="btn btn-secondary" onclick="load_service('<?php echo $row1['service_id'];?>','<?php echo $row1['cost'];?>','<?php echo $row1['tax_pc'];?>','<?php echo $row1['tax_pc_sgst'];?>')"><?php echo $row1['service_name'];?>(<?php echo  $row1['service_description'];?></button>
<?php }?>
<?php  $sql="SELECT service_id,service_name,service_description,cost,tax_pc,tax_pc_sgst FROM service order by 1";
$result = $conn->query($sql);?>
<table class="table table-striped">
<thead>
<tr>
<td>Service</td>
<td>Price</td>
<td style="visibility:<?php echo $visibility;?>"><span id="cgst_igst">CGST</span>(%)</td>
<td style="visibility:<?php echo $visibility;?>">SGST(%)</td>
<td>Qty</td>
<td>Discount</td>
<td>Cost</td>
<td style="visibility:<?php echo $visibility;?>"><span id="cgst_igst_amount">CGST</span></td>
<td style="visibility:<?php echo $visibility;?>">SGST</td>

<td>Total</td>
<td></td>
</tr>
</thead>
<tbody>
<?php 
$grand_total=0;
while ($row1 = $result->fetch_assoc()) {
	if((isset($_COOKIE["gst"]) && $_COOKIE["gst"]=="Y") ||($gst=="Y")){
	$tax_pc=$row1["tax_pc"];	
	$tax_pc_sgst=$row1["tax_pc"];
	}else{
	$tax_pc="0"	;
	$tax_pc_sgst="0";}
$sql_det="SELECT subtrans_id,service_id,cost,discount,qty,total, tax,tax_amount,tax_sgst,tax_amount_sgst,total+tax_amount+tax_amount_sgst as grand_total FROM service_trans_det where trans_id='".$trans_id."' and service_id='".$row1["service_id"]."' and active_status='A'";	
$result_det = $conn->query($sql_det);
//echo $sql_det;
$display="none";

if ($row_det = $result_det->fetch_assoc()) {
	$det_price=$row_det["cost"];
		$det_tax=$row_det["tax"];
		$tax_pc = $det_tax;
		$det_tax_sgst=$row_det["tax_sgst"];
		$tax_pc_sgst = $det_tax_sgst;
		$det_qty=$row_det["qty"];
		$det_discount=$row_det["discount"];
		$det_cost=($det_price)*$det_qty-$det_discount;
		$det_tax_amount=$row_det["tax_amount"];
		$det_tax_amount_sgst=$row_det["tax_amount_sgst"];
		$det_total = $row_det["grand_total"];
		$det_subtrans_id = $row_det["subtrans_id"];
		$display="";
		$grand_total+=$det_total;
}
	
	
	?>
<tr id="row_<?php echo $row1["service_id"];?>" style="display:<?php echo $display;?>">
<td><?php echo $row1["service_name"];?></td>
<td><input class="form-control" readonly value="<?php echo $row1["cost"];?>" id="price_<?php echo $row1["service_id"];?>" value="<?php echo $det_price;?>"></td>
<td style="visibility:<?php echo $visibility;?>"><input class="form-control" readonly value="<?php echo $tax_pc;?>" id="gst_<?php echo $row1["service_id"];?>"></td>
<td style="visibility:<?php echo $visibility;?>"><input class="form-control" readonly value="<?php echo $tax_pc_sgst;?>" id="sgst_<?php echo $row1["service_id"];?>" ></td>
<td><div class="tooltip-wrapper"><input class="form-control tooltip-input"  id="qty_<?php echo $row1["service_id"];?>" onblur="calculate('<?php echo $row1["service_id"];?>')" value="<?php echo $det_qty;?>"> <div class="tooltip-text">Once saved cannot be edited. If required, delete and reenter.</div>
</div></td>
<td><div class="tooltip-wrapper"><input class="form-control tooltip-input"  id="discount_<?php echo $row1["service_id"];?>" onblur="calculate('<?php echo $row1["service_id"];?>')"  value="<?php echo $det_discount;?>"> <div class="tooltip-text">Once saved cannot be edited. If required, delete and reenter.</div>
</div></td>


<td><input class="form-control" readonly id="cost_<?php echo $row1["service_id"];?>" value="<?php echo $det_cost;?>"></td>

<td style="visibility:<?php echo $visibility;?>"><input class="form-control" readonly  id="tax_gst_<?php echo $row1["service_id"];?>" value="<?php echo $det_tax_amount;?>"></td>
<td style="visibility:<?php echo $visibility;?>"><input class="form-control" readonly id="tax_sgst_<?php echo $row1["service_id"];?>" value="<?php echo $det_tax_amount_sgst;?>"></td>

<td><input class="form-control" readonly  id="total_<?php echo $row1["service_id"];?>" value="<?php echo $det_total;?>">
<input class="form-control" type="hidden"  id="id_<?php echo $row1["service_id"];?>" value="<?php echo $det_subtrans_id;?>"></td>
<td><button class="btn btn-xs btn-success" onclick="add_service_det('<?php echo $row1["service_id"];?>')">Save</button>
<button class="btn btn-xs btn-danger" onclick="del_service_det('<?php echo $row1["service_id"];?>')"  id="del_<?php echo $row1["service_id"];?>">X</button>
</td>
</tr>


<?php }?>
</tbody>
</table>
</div>
<div class="col-md-12">
<?php $sql_pay="SELECT p.mode,p.account,p.reference,amount FROM payments p,pay_track i where i.trans_id='".$trans_id."' and i.payment_id=p.payment_id;";
$result_pay = $conn->query($sql_pay);
if ($row_pay = $result_pay->fetch_assoc()) {
$mode = $row_pay["mode"];
$account = $row_pay["account"];	
$reference = $row_pay["reference"];	
$amount = $row_pay["amount"];			
}
?>
<table class="table">
<tr><td>Total Amount <input id="trans_amount" class="form-control" readonly value="<?php echo $grand_total;?>"></td>
<td>Pay Type <select id="pay_type" class="form-control" onchange="filter_account()">
 <option value="">--Select--</option>
	 <?php  $sql="SELECT paytype_id,paytype_name FROM paytype order by 1";
$result = $conn->query($sql);
$selected="";
while ($row = $result->fetch_assoc()) {
	if($row['paytype_name']==$mode)
		$selected="selected";
	else
		$selected="";
?>
	  <option value="<?php echo $row['paytype_id'];?>~<?php echo $row['paytype_name'];?>" <?php echo $selected;?>><?php echo $row['paytype_name'];?></option>
<?php }?>
	 </select></td>
	 <td>Account<br><select type="text"  class="form-control" id="account">
	 <option value="">--Select--</option>
	 <?php  $sql="SELECT account_id,account_name,paytype_id FROM account order by 1";
$result = $conn->query($sql);
$selected="";
while ($row = $result->fetch_assoc()) {
	if($row['account_id']==$account)
		$selected="selected";
	else
		$selected="";
?>
	  <option value="<?php echo $row['paytype_id'];?>~<?php echo $row['account_id'];?>" <?php echo $selected;?>><?php echo $row['account_name'];?></option>
<?php }?>
	 </select></td>
<td>Ref No <input id="ref_no" class="form-control" value="<?php echo $reference;?>"></td>

<td>Paid Amount <input id="paid_amount" class="form-control" value="<?php echo $amount;?>" type="number"></td>
<td><br><button class="btn btn-danger btn-lg" onclick="save_pay()">Save Pay</button></td>
</tr>
</table>
</div>
 <div class="card-body">
                            
									</div>
									</div>
                   </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
           <?php include "footer.php";?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
   <?php include "modals.php";?>
   

   
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
   <?php include "modals.php";?>
   
   
   <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title">Add</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <div class="modal-body" id="">
      <table class="table table-striped"> 
	  <tr><td>Vehicle</td><td><select  class="form-control" id="vehicle" onchange="populate_vehicle_det()">
<option value="">--select---</option>
<?php  $sql="SELECT vehicle_id,vehicle_no,vehicle_model,vehicle_brand FROM vehicle where customer_id='".$customer."' order by 1";
$result = $conn->query($sql);

while ($row1 = $result->fetch_assoc()) {?>
<option value="<?php echo $row1['vehicle_id'];?>"><?php echo $row1['item_name'];?>(<?php echo  $row1['vehicle_no'];?>,Model: <?php echo $row1['vehicle_model'];?>, Brand: <?php echo $row1['vehicle_brand'];?>)</option>
<?php }?>
	  </select>
	 
	    <input type="hidden" id="vehicle_id">
	  </td></tr>
<tr><td>Service</td><td><select  class="form-control" id="service" onchange="populate_det()">
<option value="">--select---</option>
<?php  $sql="SELECT service_id,service_name,service_description,cost,tax_pc,tax_pc_sgst FROM service order by 1";
$result = $conn->query($sql);

while ($row1 = $result->fetch_assoc()) {?>
<option value="<?php echo $row1['service_id'];?>~<?php echo $row1['cost'];?>~<?php echo $row1['tax_pc'];?>~<?php echo $row1['tax_pc_sgst'];?>"><?php echo $row1['service_name'];?>(<?php echo  $row1['service_description'];?>,Cost: <?php echo $row1['cost'];?>, Tax (%): <?php echo $row1['tax_pc'];?>)</option>
<?php }?>
	  </select>
	  <input type="hidden" id="cost">
	   <input type="hidden" id="tax_pc">
	    <input type="hidden" id="tax_pc_sgst">
	    <input type="hidden" id="service_id">
	  </td></tr>	  
     <tr><td>Qty</td><td><input type="number" id="qty" class="form-control" oninput="show_amount()"></td></tr>
	 <tr><td>Amount</td><td><input type="number"  class="form-control" id="amount"></td></tr>
	   <tr><td>Tax</td><td><input type="number"  class="form-control" id="tax" readonly></td></tr>
	     <tr><td>Tax (SGST)</td><td><input type="number"  class="form-control" id="tax_sgst" readonly></td></tr>
	<tr><td>Total</td><td><input type="number"  class="form-control" id="total" readonly></td></tr>
	
	</table>
    </div>
	 <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
		 <button type="button" class="btn btn-success" id="add">Save</button>
		
       
      </div>
  </div>
</div>
</div>

 <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title">Edit</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
<div class="modal-body" id="">
      <table class="table table-striped"> 
	  <tr><td>Vehicle</td><td><select  class="form-control" id="edit_vehicle" onchange="populate_edit_vehicle_det()">
<option value="">--select---</option>
<?php  $sql="SELECT vehicle_id,vehicle_no,vehicle_model,vehicle_brand FROM vehicle where customer_id='".$customer."' order by 1";
$result = $conn->query($sql);

while ($row1 = $result->fetch_assoc()) {?>
<option value="<?php echo $row1['vehicle_id'];?>"><?php echo $row1['item_name'];?>(<?php echo  $row1['vehicle_no'];?>,Model: <?php echo $row1['vehicle_model'];?>, Brand: <?php echo $row1['vehicle_brand'];?>)</option>
<?php }?>
	  </select>
	 
	    <input type="hidden" id="edit_vehicle_id">
	  </td></tr>
<tr><td>Service</td><td><select  class="form-control" id="edit_service" onchange="populate_edit_det()">
<option value="">--select---</option>
<?php  $sql="SELECT service_id,service_name,service_description,cost,tax_pc,tax_pc_sgst FROM service order by 1";
$result = $conn->query($sql);

while ($row1 = $result->fetch_assoc()) {?>
<option value="<?php echo $row1['service_id'];?>~<?php echo $row1['cost'];?>~<?php echo $row1['tax_pc'];?>~<?php echo $row1['tax_pc_sgst'];?>"><?php echo $row1['service_name'];?>(<?php echo  $row1['service_description'];?>,Cost: <?php echo $row1['cost'];?>, Tax (%): <?php echo $row1['tax_pc'];?>)</option>
<?php }?>
	  </select>
	  <input type="hidden" id="edit_cost">
	   <input type="hidden" id="edit_tax_pc">
	   <input type="hidden" id="edit_tax_pc_sgst">
	    <input type="hidden" id="edit_service_id">
	  </td></tr>	  
     <tr><td>Qty</td><td><input type="number" id="edit_qty" class="form-control" oninput="show_edit_amount()"></td></tr>
	 <tr><td>Amount</td><td><input type="number"  class="form-control" id="edit_amount"></td></tr>
	   <tr><td>Tax</td><td><input type="number"  class="form-control" id="edit_tax" readonly></td></tr>
	     <tr><td>Tax (SGST)</td><td><input type="number"  class="form-control" id="edit_tax_sgst" readonly></td></tr>
	<tr><td>Total</td><td><input type="number"  class="form-control" id="edit_total" readonly>
	
	
	  <input type='HIDDEN'name="trans_id" id="trans_id">
	   <input type='HIDDEN'name="trans_id" id="subtrans_id">
	  </td></tr>
	</table>
    </div>
	 <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
		 <button type="button" class="btn btn-success" id="edit">Save</button>
		
         
      </div>
      </div>
  </div>
</div>

<?php include "footer_include.php";?>
	<script src="js/jquery-3.5.1.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
	 <script src="js/demo/datatables-demo.js"></script>

<script>
var addModal = new bootstrap.Modal(document.getElementById('addModal'));
var editModal = new bootstrap.Modal(document.getElementById('editModal'));
 $(function () {
    $("#datepicker").datepicker({
        dateFormat: "dd-mm-yy"  // Set format to yyyy-mm-dd
      }).datepicker("setDate", new Date());;
	  $("#edit_datepicker").datepicker({
        dateFormat: "yy-mm-dd"  // Set format to yyyy-mm-dd
      });
  });
function show_amount(){
	let cost=$("#cost").val()==""?0:$("#cost").val();
	let qty=$("#qty").val()==""?0:$("#qty").val();
	$("#amount").val(cost*qty);
	$("#tax").val(($("#amount").val()*$("#tax_pc").val())/100);
	$("#tax_sgst").val(($("#amount").val()*$("#tax_pc_sgst").val())/100);
	let total=parseFloat($("#amount").val())+parseFloat($("#tax").val())+parseFloat($("#tax_sgst").val());
	$("#total").val(total);
}
function show_edit_amount(){
	let cost=$("#edit_cost").val()==""?0:$("#edit_cost").val();
	let qty=$("#edit_qty").val()==""?0:$("#edit_qty").val();
	$("#edit_amount").val(cost*qty);
	$("#edit_tax").val(($("#edit_amount").val()*$("#edit_tax_pc").val())/100);
		$("#edit_tax_sgst").val(($("#edit_amount").val()*$("#edit_tax_pc_sgst").val())/100);
	
	let total=parseFloat($("#edit_amount").val())+parseFloat($("#edit_tax").val())+parseFloat($("#edit_tax_sgst").val());
	$("#edit_total").val(total);
}
function populate_det(){
	let gst = "<?php echo $gst;?>";
	let parts = (document.getElementById("service").value).split("~");
	$("#service_id").val(parts[0]);
	$("#cost").val(parts[1]);
	if(gst=="Y")
	{$("#tax_pc").val(parts[2]);
$("#tax_pc_sgst").val(parts[3]);
}
	else
	{$("#tax_pc").val("0");
$("#tax_pc_sgst").val("0");
}
	//alert(parts[0]+"++"+parts[1]+"===="+parts[2]);
	show_amount();
}
function populate_vehicle_det(){
	let parts = (document.getElementById("vehicle").value).split("~");
	$("#vehicle_id").val(parts[0]);
	
}
function populate_edit_det(){
	let gst = "<?php echo $gst;?>";
	let parts = (document.getElementById("edit_service").value).split("~");
	$("#edit_service_id").val(parts[0]);
	$("#edit_cost").val(parts[1]);
	if(gst=="Y")
	{$("#edit_tax_pc").val(parts[2]);$("#edit_tax_pc_sgst").val(parts[3]);}
else
{$("#edit_tax_pc").val("0");$("#edit_tax_pc_sgst").val("0");}
	//alert(parts[0]+"++"+parts[1]+"===="+parts[2]);
	show_edit_amount();
}
function populate_edit_vehicle_det(){
	let parts = (document.getElementById("edit_vehicle").value).split("~");
	$("#edit_vehicle_id").val(parts[0]);
	
}
	 $(function () {
    $("#datepicker").datepicker({
        dateFormat: "dd-mm-yy"  // Set format to yyyy-mm-dd
      });
	  $("#edit_datepicker").datepicker({
        dateFormat: "dd-mm-yy"  // Set format to yyyy-mm-dd
      });
  });
 $('#add_opener').on('click', function() {
      //alert('Button was clicked!');
      // You can run any function here
	 addModal.show();
	/*  let module="<?php echo $module;?>";
	 $.post( "generic_form.php", {module:module})
  .done(function( data ) {
	  $("#add_block").html($.trim(data));
	    addModal.show();

  
  });*/
    });
function add_service_det(service_id){

  let service=service_id;
  let vehicle=$("#vehicle").val();
  
  let price_selector = "#price_"+service;
	let discount_selector = "#discount_"+service;
	let qty_selector = "#qty_"+service;
	let cost_selector="#cost_"+service;
	let gst_selector="#gst_"+service;
	let sgst_selector="#sgst_"+service;
	let tax_gst_selector="#tax_gst_"+service;
	let tax_sgst_selector="#tax_sgst_"+service;
	let total_selector="#total_"+service;
  
  
  
  let cost=$(price_selector).val();
 let tax_pc=$(gst_selector).val();
  let tax_pc_sgst=$(sgst_selector).val();
 let total=$(cost_selector).val();
 let tax=$(tax_gst_selector).val();
  let tax_sgst=$(tax_sgst_selector).val();
  let qty=$(qty_selector).val();
  let discount=$(discount_selector).val();
 $.post("add_service_det.php",
  {
    
    cost: cost,
	tax_pc:tax_pc,
	tax_pc_sgst:tax_pc_sgst,
	total:total,
	tax:tax,
	tax_sgst:tax_sgst,
	qty:qty,
	service_id:service,
	vehicle:vehicle,
	trans_id:$("#trans_id").val(),
	discount:discount
	
	
  },
  function(data, status){
    //alert($.trim(data));
	let id_selector="#id_"+service;
	let del_selector="#del_"+service;
	$(id_selector).val($.trim(data).split("~")[0]);
	$("#trans_amount").val($.trim(data).split("~")[1]);
	const paid_amount = document.getElementById("paid_amount");
	paid_amount.setAttribute("min", "0");
paid_amount.setAttribute("max", $.trim(data).split("~")[1]);
	$(qty_selector).prop('readonly', true);
	$(discount_selector).prop('readonly', true);
$(del_selector).prop('disabled', false);

  });
 
  
}

$('#edit').on('click', function(e) {
  let service=$("#edit_service_id").val();
  let vehicle=$("#edit_vehicle_id").val();
  let cost=$("#edit_cost").val();
 let tax_pc=$("#edit_tax_pc").val();
 let tax_pc_sgst=$("#edit_tax_pc_sgst").val();
 let total=$("#edit_amount").val();
 let tax=$("#edit_tax").val();
 let tax_sgst=$("#edit_tax_sgst").val();
  let qty=$("#edit_qty").val();
  let subtrans_id=$("#subtrans_id").val();
 $.post("edit_service_det.php",
  {
    
    cost: cost,
	tax_pc:tax_pc,
	tax_pc_sgst:tax_sgst,
	total:total,
	tax:tax,
	tax_sgst:tax_sgst,
	qty:qty,
	service_id:service,
	vehicle:vehicle,
	trans_id:"<?php echo $trans_id;?>",
	subtrans_id:subtrans_id
	
	
  },
  function(data, status){
    //alert($.trim(data));
	console.log(data);
	location.reload();
  });
 
  
});


/*$(document).ready(function() {
	 let module="<?php echo $module;?>"; 
 $.post( "generic_fetch.php", { module: module })
  .done(function( data ) {
	  let jsonData=(data);
	 if (jsonData.length === 0) {
    $('#myTable').html("<p>No data available</p>");
    return;
  }

  // 1. Generate columns dynamically based on keys of first object
  const columns = Object.keys(jsonData[0]).map(key => ({
    title: key,   // column header
    data: key     // property name to pull from
  }));

  // 2. Initialize DataTable with dynamic columns and data
  $('#myTable').DataTable({
    data: jsonData,
    columns: columns
  });
  });
});*/
function delete_it(trans_id,subtrans_id){
	var r = confirm("Are you sure that you want to delete the transaction");
	if(r){
		$.post("delete_trans_det.php",
  {
    trans_id: trans_id,
	subtrans_id:subtrans_id
  },
  function(data, status){
    //alert($.trim(data));
	location.reload();
  });
	}
	
}
function get_details(){
let vehicle_no = $("#vehicle_no").val();
		$.post("get_details.php",
  {
    vehicle_no: vehicle_no
  },
  function(data, status){
   let parts = $.trim(data).split("~");
   $("#vehicle").val(parts[0]);
   $("#vehicle_model").val(parts[1]);
   $("#no_of_wheels").val(parts[2]);
   $("#customer").val(parts[3]);
   $("#company_name").val(parts[4]);
   $("#customer_name").val(parts[5]);
  });
	
	
}
function get_gst(){
let customer = $("#customer").val();
		$.post("get_gst.php",
  {
    customer_id: customer
  },
  function(data, status){
   let parts = $.trim(data).split("~");
   var datalist=document.getElementById("gst_list");
   datalist.innerHTML="";
   parts.forEach(part => {
    const option = document.createElement("option");
    option.value = part;
    datalist.appendChild(option);
});
  });
	
	
}

function get_address(){
let customer = $("#customer").val();
		$.post("get_address.php",
  {
    customer_id: customer
  },
  function(data, status){
   let parts = $.trim(data).split("~");
   var datalist=document.getElementById("address_list");
   datalist.innerHTML="";
   parts.forEach(part => {
    const option = document.createElement("option");
    option.value = part;
    datalist.appendChild(option);
});
  });
	
	
}
function set_gst(){
	let str = document.getElementById("customer_gst").value;
	//alert(str);
	if (str.startsWith("37")) {
 $("#cgst_igst").html("CGST");
 $("#cgst_igst_amount").html("CGST");
// alert("CGST");
 
}else{
 $("#cgst_igst").html("IGST");
  $("#cgst_igst_amount").html("IGST");
 //alert("IGST"); 
}
}
function edit_it(trans_id,subtrans_id,service,vehicle,qty){
	
	//alert("====");
	$("#trans_id").val(trans_id);
	$("#subtrans_id").val(subtrans_id);
	$("#edit_service").val(service);
	
	$("#edit_vehicle").val(vehicle);
	$("#edit_qty").val(qty);
	populate_edit_det();
	populate_edit_vehicle_det();
	show_edit_amount();
	 editModal.show();
	
}

function load_service(service,price, gst,sgst){
	let trans_id=document.getElementById("trans_id").value;
	if($("#vehicle_no").val()=="" || $("#vehicle_no").val()==null){
		alert("Please enter Vehicle Details");
		return false;
	}
	let str = document.getElementById("customer_gst").value;
	if(service=="1000002"){
		let qty_selector="qty_"+service;
		document.getElementById(qty_selector).value=$("#no_of_wheels").val();
		calculate(service);
	}
	//alert(str);
	let gst_selector="gst_"+service;
	let sgst_selector="sgst_"+service
	if (str.startsWith("37")) {}else{
		document.getElementById(gst_selector).value=parseInt(document.getElementById(gst_selector).value)+parseInt(document.getElementById(sgst_selector).value);
		document.getElementById(sgst_selector).value=0;
	}
	if(trans_id=="" || trans_id==null){
			$.post("add_service.php",
  {
    vehicle_no: $("#vehicle_no").val(),
	 vehicle_model: $("#vehicle_model").val(),
	 no_of_wheels: $("#no_of_wheels").val(),
	  vehicle_odometer: $("#vehicle_odometer").val(),
	 vehicle: $("#vehicle").val(),
	 company_name: $("#company_name").val(),
	  customer_name: $("#customer_name").val(),
	  customer_address: $("#customer_address").val(),
	   customer_gst: $("#customer_gst").val(),
	    customer: $("#customer").val(),
		trans_date:$("#datepicker").val(),
		gst :"<?php echo $_COOKIE["gst"];?>"
  },
  function(data, status){
   let selector = "row_"+service;
document.getElementById(selector).style.display="";	
document.getElementById("trans_id").value = $.trim(data);


  });
	}else{let selector = "row_"+service;
document.getElementById(selector).style.display="";	}
	
	
}
function calculate(service){
	let price_selector = "price_"+service;
	let discount_selector = "discount_"+service;
	let qty_selector = "qty_"+service;
	let price=(document.getElementById(price_selector).value=="")?0:document.getElementById(price_selector).value;
	let discount=(document.getElementById(discount_selector).value=="")?0:document.getElementById(discount_selector).value;
	let qty=(document.getElementById(qty_selector).value=="")?0:document.getElementById(qty_selector).value;
	if(service=="1000002"){
	document.getElementById(qty_selector).value=$("#no_of_wheels").val();}
	let cost_selector="cost_"+service;
	document.getElementById(cost_selector).value=(parseFloat(price))*parseFloat(qty)-parseFloat(discount);
	
		if(service=="1000002"){	
	if(parseFloat(document.getElementById(cost_selector).value)<800) 	{document.getElementById(cost_selector).value="800";}
		}
	let gst_selector="gst_"+service;
	let sgst_selector="sgst_"+service;
	let tax_gst_selector="tax_gst_"+service;
	let tax_sgst_selector="tax_sgst_"+service;
	document.getElementById(tax_gst_selector).value=parseFloat(document.getElementById(cost_selector).value)*parseFloat(document.getElementById(gst_selector).value)/100.0;
	document.getElementById(tax_sgst_selector).value=parseFloat(document.getElementById(cost_selector).value)*parseFloat(document.getElementById(sgst_selector).value)/100.0;
	let total_selector="total_"+service;
	document.getElementById(total_selector).value=parseFloat(document.getElementById(tax_gst_selector).value)+parseFloat(document.getElementById(tax_sgst_selector).value)+parseFloat(document.getElementById(cost_selector).value);
}
function del_service_det(service){
let id_selector="id_"+service;	
let subtrans_id=document.getElementById(id_selector).value;	
	var r = confirm("Are you sure that you want to delete the transaction");
	if(r){
		$.post("delete_trans_det.php",
  {
    trans_id: $("#trans_id").val(),
	subtrans_id:subtrans_id
  },
  function(data, status){
    //alert($.trim(data));
	let qty_selector = "qty_"+service;
	let discount_selector="discount_"+service;
	document.getElementById(discount_selector).value=="0";
	document.getElementById(qty_selector).value=="0";
	
  });
}
}
function save_pay(){
	let paid_amount=$("#paid_amount").val();
	let pay_type=$("#pay_type").val();
	let ref_no=$("#ref_no").val();
	let trans_amount=$("#trans_amount").val();
	let account="";
	try{account=$("#account").val().split("~")[1];}catch(err){account="";}
	$.post("update_pay.php",
  {
    trans_id: $("#trans_id").val(),
	paid_amount:paid_amount,
	
	pay_type:pay_type.split("~")[1],
	account:account,
	ref_no:ref_no,
	trans_amount:trans_amount,
	 customer_name: $("#customer_name").val(),
	    customer: $("#customer").val(),
		trans_date:$("#datepicker").val(),
		gst :"<?php echo $gst;?>"
	
  },
  function(data, status){
   alert("Transaction Saved with ID: "+$("#trans_id").val());
	$('#invoice').prop('disabled', false);

  });
}
function get_invoice(){
	let trans_id= $("#trans_id").val();
	let url="service_receipt.php?trans_id="+trans_id;
	window.open(url, '_blank');
	//window.location.href=url;
}
function get_jobcard(){
	let trans_id= $("#trans_id").val();
	let url="job_card.php?trans_id="+trans_id;
	window.open(url,'_blank');
	//window.location.href=url;
}
function filter_account(){
	let pay_type=document.getElementById("pay_type").value.split("~")[0];
	//alert(pay_type);
	 $('#account option').filter(function() {
    return !$(this).val().toLowerCase().includes(pay_type);
  }).prop('disabled', true);
}

const input = document.getElementById('paid_amount');

input.addEventListener('input', function () {
    const min = parseInt(input.min);
    const max = parseInt(input.max);
    const value = parseInt(input.value);

    if (value > max) {
        input.value = max;
    } else if (value < min) {
        input.value = min;
    }
});
const tooltipWrappers = document.querySelectorAll('.tooltip-wrapper');

tooltipWrappers.forEach(wrapper => {
  const input = wrapper.querySelector('input');
  const tooltip = wrapper.querySelector('.tooltip-text');

  function showTooltip() {
    if (input.readOnly) {
      wrapper.classList.add('show');
    }
  }

  function hideTooltip() {
    wrapper.classList.remove('show');
  }

  input.addEventListener('mouseenter', showTooltip);
  input.addEventListener('focus', showTooltip);
  input.addEventListener('mouseleave', hideTooltip);
  input.addEventListener('blur', hideTooltip);
});
function setwheels(){

		let qty_selector="qty_1000002";
		let cost_selector="cost_1000002";
		document.getElementById(qty_selector).value=$("#no_of_wheels").val();
		calculate("1000002");
	if(parseFloat(document.getElementById(cost_selector).value)<800) 	{document.getElementById(cost_selector).value="800";}
	
}
</script>




  

</body>

</html>