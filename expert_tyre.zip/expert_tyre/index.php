<!DOCTYPE html>
<html lang="en">

<head>
<?php include "header_include.php";?>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
		 <?php include "db_config.php";?>
        <?php include "sidemenu.php";?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include "topmenu.php";?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                  
                    <!-- Content Row -->
                    <div class="row">
					<?php if(isset($_COOKIE["user_id"])){?>
					<table class="table table-bordered">
					<tr><td colspan=2 class="alert alert-info"><center><button class="btn btn-success btn-lg">Services</button></center></td>
					<!--<td colspan=2><center><button class="btn btn-primary btn-lg">Sales</button><center></td>-->
					</tr>
					<tr>
					<td><center><a href="go_for_services.php?GSN=N" class="btn btn-danger btn-lg">Non GST</a><center></td>
					<td><center><a href="go_for_services.php?GSN=Y" class="btn btn-lg  btn-primary"> GST</a></center></td>
					<!--<td><center><a href="go_for_services.php?GSN=N" class="btn btn-danger btn-lg">Non GST</a><center></td>
					<td><center><a href="go_for_services.php?GSN=Y" class="btn btn-lg  btn-danger"> GST</a></center></td>-->
					
					</tr>
					</table>
					
					<?php }else{?>
					<img class="img img-responsive" src="img/tyre.png" style="width:110%"/>
					<?php }?>
                    </div>

                    

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
           <?php include "footer.php";?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
   <?php include "modals.php";?>
<?php include "footer_include.php";?>
   

</body>

</html>