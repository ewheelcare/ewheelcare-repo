<?php
include "db_config.php";
$item_id=$_POST["item_id"];

$cost=$_POST["cost"];
$tax_pc=$_POST["tax_pc"];
$tax_pc_sgst=$_POST["tax_pc_sgst"];
$total=$_POST["total"];
$tax=$_POST["tax"];
$tax_sgst=$_POST["tax_sgst"];
$qty=$_POST["qty"];
$trans_id=$_POST["trans_id"];
$shop_id = $_POST["shop_id"];
$vehicle = $_POST["vehicle"];
$sql = "SELECT ifnull(max(subtrans_id),0)+1000001 subtrans_id FROM sales_trans_det where trans_id='".$trans_id."'";
$result = $conn->query($sql);

  if($row = $result->fetch_assoc()) {
	$subtrans_id=$row["subtrans_id"] ;
  }	
$sql = "insert into sales_trans_det(trans_id,subtrans_id,item_id,cost,qty,total,tax,tax_amount,active_status,created_on,created_by,shop_id,tax_amount_sgst,tax_sgst,vehicle)values('".$trans_id."','".$subtrans_id."','".$item_id."','".$cost."','".$qty."','".$total."','".$tax_pc."','".$tax."','A',now(),'".$_SESSION["user_id"]."','".$shop_id."','".$tax_sgst."','".$tax_pc_sgst."','".$vehicle."')";
$result = $conn->query($sql);
///echo $sql;
$sql = "SELECT sum(total+tax_amount+tax_amount_sgst) GRAND_TOTAL FROM sales_trans_det where trans_id='".$trans_id."' and active_status='A'";
$result = $conn->query($sql);
if($row = $result->fetch_assoc()) {
	$grand_total=$row["GRAND_TOTAL"] ;
  }	
  $sql = "update sales_trans set trans_amount='".$grand_total."'  where trans_id='".$trans_id."'";
  $conn->query($sql);
  $sql="update inventory set qty=qty-".$qty." where item_id=".$item_id." and shop_id ='". $shop_id."'" ;
  ///echo $sql;
$result = $conn->query($sql);

//echo $sql;*/
echo "Receipt added Successfully";
$conn->close();
?>