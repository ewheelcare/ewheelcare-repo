<?php 
function extractKeyFromJson($string, $keyToExtract) {
    // Try to decode
    $decoded = json_decode($string, true);

    // Check for JSON validity
    if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
        // Check if key exists
        if (array_key_exists($keyToExtract, $decoded)) {
            return $decoded[$keyToExtract];
        } else {
            return "Key '$keyToExtract' not found.";
        }
    } else {
        return "Not valid JSON.";
    }
}
?>
<?php
error_reporting(0);
include "db_config.php";
$pk =explode("_",$_POST["form_name"])[0]."_id";
$form_name=$_POST["form_name"].".json";
$json = file_get_contents($form_name);
$pk =explode("_",$_POST["form_name"])[0]."_id";
//var_dump($json);
$id=$_POST[$pk];
$data = json_decode($json, true);
$json_list=[];
$value_list=[];
foreach ($data as $entry) {
$table_name = explode(".",$entry["Save_to"])[0]	;
$json_list[$table_name]=$json_list[$table_name].",".$entry["Save_to"];
$original_value=$_POST[explode(".",$entry["Save_to"])[1]];
$actual_value = extractKeyFromJson($original_value,explode(".",$entry["Save_to"])[1]);
if($actual_value=="Not valid JSON."){
$actual_value=$original_value;
}
$value_list[$table_name]=$value_list[$table_name].",'".$actual_value."'";
}
$json_list1 = json_decode($json_list, true);
$value_list1 = json_decode($value_list, true);
//var_dump($json_list1);
// Loop through key-value pairs
foreach ($json_list as $key => $value) {
	$name_of_table = "update ".$key." set ";
	
	$col_list = explode(",",substr($value,1));
	$val_list = explode(",",substr($value_list[$key],1));
	for($i=0;$i<count($col_list);$i++){
		
	$name_of_table.=$col_list[$i]."=".$val_list[$i].","	;
	}
   $sql =  substr($name_of_table,0,strlen($name_of_table)-1);
   $sql.=" where $pk='$id'";
 // echo $sql;
   $conn->query($sql);
}
echo "Registered ". explode("_",$_POST["form_name"])[0]." with ID : ".$id;
//echo $_POST["customer.company_name"];
?>