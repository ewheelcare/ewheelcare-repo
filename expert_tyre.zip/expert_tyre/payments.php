<!DOCTYPE html>
<html lang="en">

<head>
<?php include "header_include.php";
include "db_config.php";
?>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include "sidemenu.php";?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include "topmenu.php";?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                  
                    <!-- Content Row -->
                    <div class="row">
					<div class="col-md-12">
<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal" id="add_opener">
  Add
</button>
 <div class="card-body">
                            <div class="table-responsive">
<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Trans Det</th>
                                            <th>Vendor / Customer  Det</th>
                                            <th>Details</th>
                                            <th>#</th>
                                           
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                             <th>Trans Det</th>
                                            <th>Vendor/Customer Det</th>
                                            <th>Details</th>
                                            <th>#</th>
                                        </tr>
                                    </tfoot>
									<tbody>
									<?php  $sql="SELECT p.*,a.account_name FROM payments p, account a where p.account=a.account_id and p.active_status='A'";
$result = $conn->query($sql);

while ($row = $result->fetch_assoc()) {?>
<TR>
<TD><b><?php echo $row["payment_id"];?></b>
<br> Dtd. <b><?php echo $row["payment_date"];?></b><br>
Nature :<?php echo $row["nature"];?>
</TD>
<TD><b>Vendor : <?php echo $row["vendor"];?>(<?php echo $row["vendor_name"];?>)</b>
<br> <b>Costomer : <?php echo $row["customer"];?>(<?php echo $row["customer_name"];?>)</b></TD>
<TD><?php echo $row["details"];?>
<br>Amount : <?php echo $row["amount"];?>
<br>Mode Of Pay : <?php echo $row["mode"];?>
<br>A/C :  <?php echo $row["account_name"];?>
</TD><td>
<button class="btn btn-danger btn-sm" onclick="delete_it('<?php echo $row["payment_id"];?>')">X</button>
</td>
</TR>
<?php }?>
									</tbody>
									</table>
									</div>
									</div>
									</div>
                    </div>

                    

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
           <?php include "footer.php";?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
   <?php include "modals.php";?>
   
   
   <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title">Add</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <div class="modal-body" id="">
      <table class="table table-striped">  
     <tr><td>Date of Trnsaction</td><td><input type="text" id="datepicker" class="form-control"></td></tr>
	 <tr><td>Nature</td><td><select type="text"  class="form-control" id="nature" onchange="set_vendor_customer()">
	 <option value="">--Select--</option>
	  <option value="DEBIT">DEBIT</option>
	   <option value="CREDIT">CREDIT</option>
	 </select></td></tr>
	  <tr><td>Vendor</td><td><input  class="form-control" id="vendor" list="vendor_list">
<?php  $sql="SELECT vendor_id,company_name FROM vendor order by 1";
$result = $conn->query($sql);?>
<datalist id="vendor_list">
<?php while ($row = $result->fetch_assoc()) {?>
<option value="<?php echo $row['vendor_id'];?>~<?php echo $row['company_name'];?>"></option>
<?php }?>
	  </datalist></td></tr>
	   <tr><td>Customer</td><td><input  class="form-control" id="customer" list="customer_list">
<?php  $sql="SELECT customer_id,company_name FROM customer order by 1";
$result = $conn->query($sql);?>
<datalist id="customer_list">
<?php while ($row = $result->fetch_assoc()) {?>
<option value="<?php echo $row['customer_id'];?>~<?php echo $row['company_name'];?>"></option>
<?php }?>
	  </datalist></td></tr>
 <tr><td>Mode</td><td><select type="text"  class="form-control" id="mode" onchange="filter_account()">
	 <option value="">--Select--</option>
	 <?php  $sql="SELECT paytype_id,paytype_name FROM paytype order by 1";
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()) {
?>
	  <option value="<?php echo $row['paytype_id'];?>~<?php echo $row['paytype_name'];?>"><?php echo $row['paytype_name'];?></option>
<?php }?>
	 </select></td></tr>	
<tr><td>Account</td><td><select type="text"  class="form-control" id="account">
	 <option value="">--Select--</option>
	 <?php  $sql="SELECT account_id,account_name,paytype_id FROM account order by 1";
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()) {
?>
	  <option value="<?php echo $row['paytype_id'];?>~<?php echo $row['account_id'];?>"><?php echo $row['account_name'];?></option>
<?php }?>
	 </select></td></tr>	
<tr><td>Amount</td><td><input type="number" id="amount" name="amount"></td></tr>
<tr><td>Reference</td><td><input type="text" id="reference" name="reference"></td></tr>

	</table>
    </div>
	 <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
		 <button type="button" class="btn btn-success" id="add">Save</button>
		
       
      </div>
  </div>
</div>
</div>

 <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title">Edit</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <div class="modal-body" id="">
      <table class="table table-striped">  
     <tr><td>Date of Trnsaction</td><td><input type="text" id="edit_datepicker" class="form-control"></td></tr>
	 <tr><td>Details</td><td><input type="text"  class="form-control" id="edit_details"></td></tr>
	  <tr><td>Vendor</td><td><input  class="form-control" id="edit_vendor" list="edit_vendor_list">
<?php  $sql="SELECT vendor_id,company_name FROM vendor order by 1";
$result = $conn->query($sql);?>
<datalist id="edit_vendor_list">
<?php while ($row = $result->fetch_assoc()) {?>
<option value="<?php echo $row['vendor_id'];?>~<?php echo $row['company_name'];?>"></option>
<?php }?>
	  </datalist>
	  </select>
	  <input type='HIDDEN'name="trans_id" id="trans_id">
	  </td></tr>
	</table>
    </div>
	 <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
		 <button type="button" class="btn btn-success" id="edit">Save</button>
		
       
      </div>
  </div>
</div>
</div>
<?php include "footer_include.php";?>
	<script src="js/jquery-3.5.1.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
	 <script src="js/demo/datatables-demo.js"></script>

<script>
var addModal = new bootstrap.Modal(document.getElementById('addModal'));
var editModal = new bootstrap.Modal(document.getElementById('editModal'));
	 $(function () {
    $("#datepicker").datepicker({
        dateFormat: "yy-mm-dd"  // Set format to yyyy-mm-dd
      }).datepicker("setDate", new Date());;
	  $("#edit_datepicker").datepicker({
        dateFormat: "yy-mm-dd"  // Set format to yyyy-mm-dd
      });
  });
 $('#add_opener').on('click', function() {
      //alert('Button was clicked!');
      // You can run any function here
	 addModal.show();
	/*  let module="<?php echo $module;?>";
	 $.post( "generic_form.php", {module:module})
  .done(function( data ) {
	  $("#add_block").html($.trim(data));
	    addModal.show();

  
  });*/
    });

$('#add').on('click', function(e) {
	let vendor="",vendor_name="",customer="",customer_name="";
  let payment_date=$("#datepicker").val();
  let nature=$("#nature").val();
 try{ vendor=$("#vendor").val().split("~")[0];
   vendor_name=$("#vendor").val().split("~")[1];
   customer=$("#customer").val().split("~")[0];
   customer_name=$("#customer").val().split("~")[1];
 }catch(err){
vendor="";vendor_name="";customer="";customer_name="";	 
 }
  let mode=$("#mode").val();
  let account=$("#account").val();
  let amount=$("#amount").val();
  let reference=$("#reference").val();
 $.post("add_payment.php",
  {
    payment_date: payment_date,
    nature: nature,
	vendor:vendor,
	vendor_name:vendor_name,
	customer:customer,
	customer_name:customer_name,
	mode:mode.split("~")[1],
	account:account.split("~")[1],
	amount:amount,
	reference:reference
	
	
  },
  function(data, status){
    alert($.trim(data));
	console.log($.trim(data));
	location.reload();
  });
 
  
});

$('#edit').on('click', function(e) {
  let trans_date=$("#edit_datepicker").val();
  let details=$("#edit_details").val();
 let vendor=$("#edit_vendor").val().split("~")[0];
 let trans_id=$("#trans_id").val();
 $.post("update_receipt.php",
  {
    trans_date: trans_date,
    details: details,
	vendor:vendor,
	trans_id:trans_id
  },
  function(data, status){
    alert($.trim(data));
	location.reload();
  });
 
  
});
function set_vendor_customer(){
	let nature=document.getElementById("nature").value;
	if(nature=="DEBIT"){
		document.getElementById("vendor").disabled=false;
		document.getElementById("customer").disabled=true;
	}else{
		document.getElementById("vendor").disabled=true;
		document.getElementById("customer").disabled=false;
		
	}
	
	
}
function filter_account(){
	let pay_type=document.getElementById("mode").value.split("~")[0];
	//alert(pay_type);
	 $('#account option').filter(function() {
    return !$(this).val().toLowerCase().includes(pay_type);
  }).prop('disabled', true);
}

/*$(document).ready(function() {
	 let module="<?php echo $module;?>"; 
 $.post( "generic_fetch.php", { module: module })
  .done(function( data ) {
	  let jsonData=(data);
	 if (jsonData.length === 0) {
    $('#myTable').html("<p>No data available</p>");
    return;
  }

  // 1. Generate columns dynamically based on keys of first object
  const columns = Object.keys(jsonData[0]).map(key => ({
    title: key,   // column header
    data: key     // property name to pull from
  }));

  // 2. Initialize DataTable with dynamic columns and data
  $('#myTable').DataTable({
    data: jsonData,
    columns: columns
  });
  });
});*/
function delete_it(trans_id){
	var r = confirm("Are you sure that you want to delete the transaction");
	if(r){
		$.post("delete_payment.php",
  {
    payment_id: trans_id
  },
  function(data, status){
    alert($.trim(data));
	location.reload();
  });
	}
	
}

function edit_it(trans_id,trans_date,vendor,details){
	
	//alert("====");
	$("#trans_id").val(trans_id);
	$("#edit_datepicker").val(trans_date);
	
	$("#edit_details").val(details);
	let datalist=document.getElementById("edit_vendor_list");
	const options = datalist.getElementsByTagName('option');

      // Set partial value
      

      // Try to auto-complete
      for (let i = 0; i < options.length; i++) {
        const optionVal = options[i].value.toLowerCase();
        if (optionVal.startsWith(vendor)) {
         // input.value = options[i].value;
		  $("#edit_vendor").val(options[i].value);
          break;
        }
      }
	 editModal.show();
	
}
</script>


</script>

  

</body>

</html>