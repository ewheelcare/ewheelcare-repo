<!DOCTYPE html>
<html lang="en">

<head>
<?php include "header_include.php";
include "db_config.php";
?>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include "sidemenu.php";?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include "topmenu.php";?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                  
                    <!-- Content Row -->
                    <div class="row">
					<div class="col-md-12">
					<form action="#" method="post">
 <table class="table table-striped">  
     <tr>
	 <td>From date<br><input type="text" name="from_date" id="from_date" class="form-control"></td>
	 <td>To date<br><input type="text" name="to_date" id="to_date" class="form-control"></td>
	 <td>Vendor<br><select  class="form-control" name="vendor">
	 <option value="">--select---</option>
<?php  $sql="SELECT vendor_id,company_name FROM vendor order by 1";
$result = $conn->query($sql);

while ($row = $result->fetch_assoc()) {?>
<option value="<?php echo $row['vendor_id'];?>"><?php echo $row['company_name'];?></option>
<?php }?>
	  </select></td>
	  <td>Item<br><select  class="form-control" name="item">
<option value="">--select---</option>
<?php  $sql="SELECT i.item_id,i.item_name,i.item_description,i.cost,i.tax_pc,iv.qty FROM item i left outer join (select sum(qty) qty,item_id from inventory group by item_id) iv on iv.item_id=i.item_id order by 1";
$result = $conn->query($sql);

while ($row1 = $result->fetch_assoc()) {?>
<option value="<?php echo $row1['item_id'];?>"><?php echo $row1['item_name'];?>(<?php echo  $row1['item_description'];?></option>
<?php }?>
	  </select>
	  </td>
	  <td><input type="submit" class="btn btn-primary btn-sm" value="Search"></td>
	 </tr>
	 </table>
		</form>
		
		<?php 
		$from_date=$_POST["from_date"];
		$to_date=$_POST["to_date"];
		$item=$_POST["item"];
		$vendor=$_POST["vendor"];
	//	echo $from_date."====".$to_date."====".$item."=====".$customer;?>
	<button class="btn btn-sm btn-primary" type="button" STYLE="float:right;margin:3px;"  onclick="print_table()">Excel</button>
	
	<table class="table table-striped table-bordered" id="report_table"><thead>
	<tr>
	<td>Trans details</td>
	<td>Vendor details</td>
	<td>Product details</td>
	<td>Cost details</td>
	<tr>
	</thead><tbody>	
		<?php $sql="SELECT s.trans_id,d.subtrans_id,s.trans_date,c.company_name,i.item_name,d.total,d.tax_amount FROM receipt_trans s, receipt_trans_det d,vendor c,item i WHERE s.trans_id=d.trans_id and s.active_status='A' AND d.active_status='A' AND s.vendor=c.vendor_id and d.item_id=i.item_id ";
		if(isset($from_date) && $from_date!="")
		$sql.="  AND s.trans_date BETWEEN  STR_TO_DATE('".$from_date."', '%d-%m-%Y') AND  STR_TO_DATE('".$to_date."', '%d-%m-%Y') ";
if(isset($vendor) && $vendor!="")
	$sql.="  AND s.vendor='".$vendor."'";
if(isset($item) && $item!="")
$sql.="  AND d.item_id='".$item."'";
	//echo $sql;	
		$result = $conn->query($sql);
while ($row = $result->fetch_assoc()) {
	
$trans_id= $row["trans_id"];
$subtrans_id=$row["subtrans_id"];
$trans_date=$row["trans_date"];
$company_name=$row["company_name"];
$item_name=$row["item_name"];
$total=$row["total"];
$tax_amount=$row["tax_amount"];
$gst=$row["gst"];?>
<tr>
	<td><?php echo $trans_id;?>(<?php echo $subtrans_id;?>) Dtd <?php echo $trans_date;?> </td>
	<td><?php echo $company_name;?></td>
	<td><?php echo $item_name;?></td>
	<td>Amount : <?php echo $total;?> + Tax : <?php echo $tax_amount;?> = <?php echo $total+$tax_amount;?> </td>
	<tr>
<?php }
		?>
		</tbody></table>
		
		
					
									
									</div>
                    </div>

                    

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
           <?php include "footer.php";?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
   <?php include "modals.php";?>
   
   
   

<?php include "footer_include.php";?>
	<script src="js/jquery-3.5.1.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
	 <script src="js/demo/datatables-demo.js"></script>

<script>
 $(function () {
    $("#from_date").datepicker({
        dateFormat: "dd-mm-yy"  // Set format to yyyy-mm-dd
      });
	  $("#to_date").datepicker({
        dateFormat: "dd-mm-yy"  // Set format to yyyy-mm-dd
      });
  });

</script>


<script src="js/tableToExcel.js"></script>
 <script type="text/javascript">
		function print_table(){
		TableToExcel.convert(document.getElementById("report_table"));
		}
		</script>

  

</body>

</html>