<?php
if (!isset($_COOKIE["user_id"])) {
    header("Location: login.php?redirect=" . urlencode($_SERVER['REQUEST_URI']));
    exit();
}
?>

<?php
include "db_config.php";

// Collect and sanitize POST data


$trans_date = isset($_POST["trans_date"]) ? $_POST["trans_date"] : '';
$customer = isset($_POST["customer"]) ? $_POST["customer"] : '';

$company_name = isset($_POST["company_name"]) ? $_POST["company_name"] : '';
$customer_name = isset($_POST["customer_name"]) ? $_POST["customer_name"] : '';
$customer_mobile = isset($_POST["customer_mobile"]) ? $_POST["customer_mobile"] : '0';
// Added this as it was used but not defined

// Get new transaction ID
$sql = "SELECT IFNULL(MAX(dc_id), 1000000) + 1  AS dc_id FROM delivery_challan";
$result = $conn->query($sql);
$trans_id = 1000001;

if ($result && $row = $result->fetch_assoc()) {
    $trans_id = $row["dc_id"];
}

// Prepare insert statement
$sql = "INSERT INTO delivery_challan (
    dc_id, customer, dc_date, active_status, company_name, customer_name,customer_mobile) VALUES ('".$trans_id."','".$customer."', STR_TO_DATE('".$trans_date."', '%d-%m-%Y'), 'A', '".$company_name."', '".$customer_name."','".$customer_mobile."')";
//echo $sql;
 $conn->query($sql);

// Execute and check result
    echo $trans_id;

$conn->close();
?>
