<?php
include "db_config.php";
$from_shop=$_POST["from_shop"];
$from_qty=$_POST["from_qty"];
$to_shop=$_POST["to_shop"];
$item=$_POST["item"];
$sql="update inventory set qty=qty-".$from_qty." where item_id=".$item." and shop_id='".$from_shop."'" ;
$result = $conn->query($sql);
$sql="update inventory set qty=qty+".$from_qty." where item_id=".$item." and shop_id='".$to_shop."'" ;
$result = $conn->query($sql);
if ($result) {
if($conn->affected_rows<=0){
   $sql="insert into inventory (item_id,shop_id,qty) values ('".$item."','".$to_shop."',".$from_qty.")";
   echo $sql;
$result = $conn->query($sql);
}
}
?>