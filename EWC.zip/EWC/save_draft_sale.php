<?php 
include "db_config.php";
$trans_id=$_POST["value"];
$trans_amount=$_POST["trans_amount"];
$roundoff=$_POST["roundoff"];
$discount=$_POST["discount"];
$ver = $_POST["ver"];
$sql="update  sales_trans set active_status='A',discount='".$discount."',roundoff='".$roundoff."',ver='".$ver."' WHERE  trans_id='".$trans_id."' ";
$result = $conn->query($sql);
echo $sql;
$sql = "SELECT sum(total) GRAND_TOTAL FROM sales_trans_det where trans_id='".$trans_id."' and active_status!='Z' and ifnull(account,'Y')='Y' and ver='".$ver."'";
//echo $sql;
$result = $conn->query($sql);
if($row = $result->fetch_assoc()) {
	$grand_total=$row["GRAND_TOTAL"] ;
  }	
  	$grand_total=	$grand_total+($discount)+($roundoff);
  $sql = "update sales_trans set trans_amount='".$grand_total."'  where trans_id='".$trans_id."'";
  $conn->query($sql);


?>