<?php
if (!isset($_COOKIE["user_id"])) {
    header("Location: login.php?redirect=" . urlencode($_SERVER['REQUEST_URI']));
    exit();
}
?>
<?php
include "db_config.php";

// Collect and sanitize POST data
$dc_id = isset($_POST["dc_id"]) ?$_POST["dc_id"]: '';
$trans_id = isset($_POST["trans_id"]) ?$_POST["trans_id"]: '';
$subtrans_id = isset($_POST["sub_trans_id"]) ? $_POST["sub_trans_id"]: '';
$item_id = isset($_POST["item_id"]) ? $_POST["item_id"]:'';
$despatched = isset($_POST["qty"]) ? $_POST["qty"]:'';
$vehicle = isset($_POST["vehicle"]) ? $_POST["vehicle"]:'0';
$odometer = isset($_POST["odometer"]) ? $_POST["odometer"]:'0';
// Added this as it was used but not defined

// Prepare insert statement
$sql_check="select qty from inventory_block  where item_id=".$item_id." and trans_id ='". $trans_id."'";
//echo $sql_check;
$result = $conn->query($sql_check);
if($row = $result->fetch_assoc()) {
	//echo "here";
$inventory=	$row["qty"] ;
 $sql_upd="update inventory_block set qty=qty-".$despatched." where item_id=".$item_id." and trans_id ='". $trans_id."'" ;
 $conn->query($sql_upd);

}
$sql = "INSERT INTO delivery_challan_det (
    dc_id, trans_id, subtrans_id, active_status, item_id, despatched,vehicle,odometer) VALUES ('".$dc_id."','".$trans_id."','".$subtrans_id."','A', '".$item_id."', '".$despatched."','".$vehicle."','".$odometer."')";
//echo $sql;
 $conn->query($sql);
$sql = "UPDATE sales_trans_det SET pending = pending - " . $despatched . 
       ", vehicle = '" . $vehicle . 
       "', run_km = '" . $odometer . 
       "' WHERE trans_id = '" . $trans_id . 
       "' AND subtrans_id = '" . $subtrans_id . 
       "' AND item_id = '" . $item_id . "'";$conn->query($sql);
    echo $dc_id;

?>
