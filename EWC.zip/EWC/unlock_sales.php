<?php 
include "db_config.php";
$trans_id=$_POST["trans_id"];
$ver=$_POST["ver"];
$new_ver=$ver+1;
$sql="update  sales_trans set active_status='D' WHERE  trans_id='".$trans_id."'";
$result = $conn->query($sql);
echo $sql;
$sql="INSERT INTO sales_trans_det (
trans_id, subtrans_id, item_id, cost, qty, tax, tax_amount, total,
created_by, created_on, modified_by, modified_on, active_status,
vehicle, shop_id, tax_sgst, tax_amount_sgst, run_km, discount, pending,
tax_igst, tax_amount_igst, roundoff, account, price, remarks, parent, ver,perc
)SELECT trans_id, subtrans_id, item_id, cost, qty, tax, tax_amount, total,
created_by, created_on, modified_by, modified_on, active_status,
vehicle, shop_id, tax_sgst, tax_amount_sgst, run_km, discount, pending,
tax_igst, tax_amount_igst, roundoff, account, price, remarks, parent, '".$new_ver."',perc
FROM sales_trans_det
WHERE ver = '".$ver."' and trans_id='".$trans_id."'";
echo $sql;
$result = $conn->query($sql); 
?>