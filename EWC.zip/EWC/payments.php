<?php
if (!isset($_COOKIE["user_id"])) {
    header("Location: login.php?redirect=" . urlencode($_SERVER['REQUEST_URI']));
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php include "header_include.php";
include "db_config.php";
?>
	<style>
	
	.fullscreen-modal {
    width: 100vw;
    height: 100vh;
    margin: 0;
    border-radius: 0;
}

.modal-dialog {
    max-width: 100%;
    margin: 0;
}

.modal-content {
    height: 100vh;
}
	</style>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include "sidemenu.php";?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include "topmenu.php";?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                  
                    <!-- Content Row -->
                    <div class="row">
					<div class="col-md-12">
						<?php $now_nature=$_GET["nature"];?>
<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal" id="add_opener">
  Add
</button>
 <div class="card-body">
                            <div class="table-responsive">
<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0" style="font-size:85%">
                                    <thead class="btn-primary">
                                        <tr>
                                            <th>Trans ID</th>
											<th>Trans Date</th>
                                            <th>Vendor / Customer  Det</th>
                                           
											 <th>Amount</th>
											 <th>Mode</th>
											 <th>Bank</th>
                                            <th>#</th>
                                           
                                        </tr>
                                    </thead>
                                    <tfoot class="btn-primary">
                                        <tr>
                                              <th>Trans ID</th>
											<th>Trans Date</th>
                                            <th>Vendor / Customer  Det</th>
                                           
											 <th>Amount</th>
											 <th>Mode</th>
											 <th>Bank</th>
                                            <th>#</th>
                                           
                                        </tr>
                                    </tfoot>
									<tbody>
									<?php  $sql="SELECT p.*,a.account_name FROM payments p, account a where p.account=a.account_id and p.active_status='A' and p.nature='".$now_nature."'";
$result = $conn->query($sql);

while ($row = $result->fetch_assoc()) {?>
<TR>
<td><b><?php echo $row["payment_id"];?></b>, Nature :<?php echo $row["nature"];?></td>
<td> <b><?php echo $row["payment_date"];?></b></td>
<td><b>	<?php echo $row["vendor_name"];?></b>
<?php echo $row["customer_name"];?></b>
 </td>
 	<td> <?php echo $row["amount"];?></td>
	 <td> <?php echo $row["mode"];?></td>
<td><?php echo $row["account_name"];?>
</td>
<td>
<button class="btn btn-danger btn-sm" onclick="delete_it('<?php echo $row["payment_id"];?>','<?php echo $row["nature"];?>','<?php echo $row["account"];?>','<?php echo $row["account_to"];?>','<?php echo $row["amount"];?>','<?php echo $row["mode"];?>')">X</button>
<?php if(($row["nature"]=="DEBIT" || $row["nature"]=="CREDIT")&&($row["verified"]=="N")){?>
	
<button class="btn btn-success btn-sm" onclick="approve_pay('<?php echo $row["payment_id"];?>','<?php echo $row["nature"];?>','<?php echo $row["amount"];?>')">Approve</button>
<?php }?>

</TR>
<?php }?>
									</tbody>
									</table>
									</div>
									</div>
									</div>
                    </div>

                    

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
           <?php include "footer.php";?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
   <?php include "modals.php";?>
   
   
   <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-fullscreen" role="document">
    <div class="modal-content fullscreen-modal">

      <div class="modal-header">
        <h5 class="modal-title">Add</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <div class="modal-body" id="">
      <table class="table table-striped">  
     <tr><td>Date of Trnsaction</td><td><input type="text" id="datepicker" class="form-control"></td></tr>
	 <tr><td>Nature</td><td><select type="text"  class="form-control" id="nature" onchange="set_vendor_customer()">
	 <option value="">--Select--</option>
	  <option value="DEBIT">PAYMENT</option>
	   <option value="CREDIT">RECEIPT</option>
	  <?PHP if( isset($_COOKIE["SA"])){?>
	    <option value="CASHTOBANK">CASH TO BANK</option>
	    <option value="BANKTOCASH">BANK TO CASH</option>
			    <option value="BANKTOBANK">BANK TO BANK</option>
	  <?PHP }?>
	 </select></td></tr>
	  <tr><td>Vendor</td><td><input  class="form-control" id="vendor" list="vendor_list">
<?php  $sql="SELECT vendor_id,company_name,owner_name FROM vendor order by 1";
$result = $conn->query($sql);?>
<datalist id="vendor_list">
<?php while ($row = $result->fetch_assoc()) {?>
<option value="<?php echo $row['vendor_id'];?>~<?php echo $row['company_name'];?>~<?php echo $row['owner_name'];?>"></option>
<?php }?>
	  </datalist></td></tr>
	   <tr><td>Customer</td><td><input  class="form-control" id="customer" list="customer_list">
<?php  $sql="SELECT customer_id,company_name,owner_name FROM customer order by 1";
$result = $conn->query($sql);?>
<datalist id="customer_list">
<?php while ($row = $result->fetch_assoc()) {?>
<option value="<?php echo $row['customer_id'];?>~<?php echo $row['company_name'];?>~<?php echo $row['owner_name'];?>"></option>
<?php }?>
	  </datalist></td></tr>
 <tr><td>Mode</td><td><select type="text"  class="form-control" id="mode" onchange="filter_account()">
	 <option value="">--Select--</option>
	 <?php  $sql="SELECT paytype_id,paytype_name FROM paytype order by 1";
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()) {
?>
	  <option value="<?php echo $row['paytype_id'];?>~<?php echo $row['paytype_name'];?>"><?php echo $row['paytype_name'];?></option>
<?php }?>
	 </select></td></tr>	
<tr><td>Account (From in case of Transfer)</td><td><select type="text"  class="form-control" id="account">
	 <option value="">--Select--</option>
	 <?php  $sql="SELECT account_id,account_name,paytype_id FROM account order by 1";
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()) {
?>
	  <option value="<?php echo $row['paytype_id'];?>~<?php echo $row['account_id'];?>"><?php echo $row['account_name'];?></option>
<?php }?>
	 </select></td></tr>	
	 <tr><td>Account (To in case of Transfer)</td><td><select type="text"  class="form-control" id="account_to">
	 <option value="">--Select--</option>
	 <?php  $sql="SELECT account_id,account_name,paytype_id FROM account order by 1";
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()) {
?>
	  <option value="<?php echo $row['paytype_id'];?>~<?php echo $row['account_id'];?>"><?php echo $row['account_name'];?></option>
<?php }?>
	 </select></td></tr>
<tr><td>Amount</td><td><input type="number" id="amount" name="amount"></td></tr>
<tr><td>Reference</td><td><input type="text" id="reference" name="reference"></td></tr>

	</table>
    </div>
	 <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
		 <button type="button" class="btn btn-success" id="add">Save</button>
		
       
      </div>
  </div>
</div>
</div>

 <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title">Edit</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <div class="modal-body" id="">
      <table class="table table-striped">  
     <tr><td>Date of Trnsaction</td><td><input type="text" id="edit_datepicker" class="form-control"></td></tr>
	 <tr><td>Details</td><td><input type="text"  class="form-control" id="edit_details"></td></tr>
	  <tr><td>Vendor</td><td><input  class="form-control" id="edit_vendor" list="edit_vendor_list">
<?php  $sql="SELECT vendor_id,company_name FROM vendor order by 1";
$result = $conn->query($sql);?>
<datalist id="edit_vendor_list">
<?php while ($row = $result->fetch_assoc()) {?>
<option value="<?php echo $row['vendor_id'];?>~<?php echo $row['company_name'];?>"></option>
<?php }?>
	  </datalist>
	  </select>
	  <input type='HIDDEN'name="trans_id" id="trans_id">
	  </td></tr>
	</table>
    </div>
	 <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
		 <button type="button" class="btn btn-success" id="edit">Save</button>
		
       
      </div>
  </div>
</div>
</div>
<?php include "footer_include.php";?>
	<script src="js/jquery-3.5.1.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
	 <script src="js/demo/datatables-demo.js"></script>

<script>
var addModal = new bootstrap.Modal(document.getElementById('addModal'));
var editModal = new bootstrap.Modal(document.getElementById('editModal'));
$(document).ready(function () {
   document.getElementById("nature").value="<?php echo $now_nature;?>";
	set_vendor_customer();
});
	
	
	
	 $(function () {
    $("#datepicker").datepicker({
        dateFormat: "dd-mm-yy"  // Set format to yyyy-mm-dd
      }).datepicker("setDate", new Date());;
	  $("#edit_datepicker").datepicker({
        dateFormat: "dd-mm-yy"  // Set format to yyyy-mm-dd
      });
  });
 $('#add_opener').on('click', function() {
      //alert('Button was clicked!');
      // You can run any function here
	 addModal.show();
	/*  let module="<?php echo $module;?>";
	 $.post( "generic_form.php", {module:module})
  .done(function( data ) {
	  $("#add_block").html($.trim(data));
	    addModal.show();

  
  });*/
    });

$('#add').on('click', function(e) {
	let vendor="",vendor_name="",customer="",customer_name="";
  let payment_date=$("#datepicker").val();
  let nature=$("#nature").val();
 try{ vendor=$("#vendor").val().split("~")[0];
   vendor_name=$("#vendor").val().split("~")[1];
   customer=$("#customer").val().split("~")[0];
   customer_name=$("#customer").val().split("~")[1];
 }catch(err){
vendor="";vendor_name="";customer="";customer_name="";	 
 }
  let mode="";
  try{mode=$("#mode").val().split("~")[1];}catch(err){mode="";}
 let account="";
	try{account=$("#account").val().split("~")[1];}catch(err){account="";}
	let account_to="";
	try{account_to=$("#account_to").val().split("~")[1];}catch(err){account_to="";}
  
  let amount=$("#amount").val();
  let reference=$("#reference").val();
 $.post("add_payment.php",
  {
    payment_date: payment_date,
    nature: nature,
	vendor:vendor,
	vendor_name:vendor_name,
	customer:customer,
	customer_name:customer_name,
	mode:mode,
	account:account,
	account_to:account_to,
	amount:amount,
	reference:reference
	
	
  },
  function(data, status){
    alert($.trim(data));
	console.log($.trim(data));
	location.reload();
  });
 
  
});

$('#edit').on('click', function(e) {
  let trans_date=$("#edit_datepicker").val();
  let details=$("#edit_details").val();
 let vendor=$("#edit_vendor").val().split("~")[0];
 let trans_id=$("#trans_id").val();
 $.post("update_receipt.php",
  {
    trans_date: trans_date,
    details: details,
	vendor:vendor,
	trans_id:trans_id
  },
  function(data, status){
    alert($.trim(data));
	location.reload();
  });
 
  
});
function set_vendor_customer(){
	let nature=document.getElementById("nature").value;
	if(nature=="DEBIT"){
		document.getElementById("vendor").disabled=false;
		document.getElementById("customer").disabled=true;
		document.getElementById("account_to").disabled=true;
	}else if(nature=="CREDIT") {
		document.getElementById("vendor").disabled=true;
		document.getElementById("customer").disabled=false;
			document.getElementById("account_to").disabled=true;
		
	}else{
		document.getElementById("vendor").disabled=true;
		document.getElementById("customer").disabled=true;
		document.getElementById("mode").disabled=true;
		//if(document.getElementById("nature").value=="BANKTOBANK")
		{document.getElementById("account_to").disabled=false;}
	/*else
	{document.getElementById("account_to").disabled=true;}*/
	}
	
	
}
function filter_account(){
	let pay_type=document.getElementById("mode").value.split("~")[0];
	//alert(pay_type);
	 $('#account option').filter(function() {
    return !$(this).val().toLowerCase().includes(pay_type);
  }).prop('disabled', true);
}

/*$(document).ready(function() {
	 let module="<?php echo $module;?>"; 
 $.post( "generic_fetch.php", { module: module })
  .done(function( data ) {
	  let jsonData=(data);
	 if (jsonData.length === 0) {
    $('#myTable').html("<p>No data available</p>");
    return;
  }

  // 1. Generate columns dynamically based on keys of first object
  const columns = Object.keys(jsonData[0]).map(key => ({
    title: key,   // column header
    data: key     // property name to pull from
  }));

  // 2. Initialize DataTable with dynamic columns and data
  $('#myTable').DataTable({
    data: jsonData,
    columns: columns
  });
  });
});*/
function delete_it(trans_id,nature,account,account_to,amount,mode ){
	var r = confirm("Are you sure that you want to delete the transaction");
	if(r){
		$.post("delete_payment.php",
  {
    payment_id: trans_id,
	nature:nature,
	account:account,
	account_to:account_to,
	amount:amount,
			mode:mode
	
  },
  function(data, status){
    alert($.trim(data));
	location.reload();
  });
	}
	
}
function approve_pay(trans_id,nature,amount ){
	var r = confirm("Are you sure that you want to approve the transaction");
	if(r){
		$.post("approve_pay.php",
  {
    payment_id: trans_id,
	nature:nature,
	
	amount:amount
	
  },
  function(data, status){
    alert($.trim(data));
	location.reload();
  });
	}
	
}
function edit_it(trans_id,trans_date,vendor,details){
	
	//alert("====");
	$("#trans_id").val(trans_id);
	$("#edit_datepicker").val(trans_date);
	
	$("#edit_details").val(details);
	let datalist=document.getElementById("edit_vendor_list");
	const options = datalist.getElementsByTagName('option');

      // Set partial value
      

      // Try to auto-complete
      for (let i = 0; i < options.length; i++) {
        const optionVal = options[i].value.toLowerCase();
        if (optionVal.startsWith(vendor)) {
         // input.value = options[i].value;
		  $("#edit_vendor").val(options[i].value);
          break;
        }
      }
	 editModal.show();
	
}
</script>


</script>

  

</body>

</html>