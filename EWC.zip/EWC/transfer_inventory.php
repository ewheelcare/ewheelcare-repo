<!DOCTYPE html>
<html lang="en">

<head>
<?php include "header_include.php";
include "db_config.php";
?>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include "sidemenu.php";?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include "topmenu.php";?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
				<div class="alert alert-info" style="text-align:center;font-size:80%;font-weight:bold">Stock</div> 
<div class="row">
<div class="col-md-12">
 <div class="table-responsive">
<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
<thead>
<tr>
<td>Shop</td>
<td>Item</td>
<td>Quantity</td>
</tr>
</thead>
<?php $sql="SELECT i.qty,s.shop_name,it.item_name FROM inventory i,shop s, item it where s.shop_id=i.shop_id and i.item_id=it.item_id;";
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()) {
	
$shop_name=$row["shop_name"];
$item_name=$row["item_name"];
$qty=$row["qty"];?>
<tr><td><?php echo $shop_name;?></td><td><?php echo $item_name;?></td><td><?php echo $qty;?></td></tr>
<?php }?>
</table>
	</div>
</div>
                        

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
           <?php include "footer.php";?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
   <?php include "modals.php";?>
   
   
   
<?php include "footer_include.php";?>
	<script src="js/jquery-3.5.1.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
	 <script src="js/demo/datatables-demo.js"></script>

<script>
let from_shop="";
let from_qty="";
function open_draw_box(shop){
let sel = "draw_"+shop;
from_shop = shop;
document.getElementById(sel).style.display="";	
}
function set_storage(){
	let sel = "draw_"+from_shop;
	from_qty = document.getElementById(sel).value;
}

function deposit_box(shop){
let to_shop=shop;
 $.post("draw_deposit.php",
  {
    
    from_shop: from_shop,
	from_qty:from_qty,
	to_shop:to_shop,
	item:"<?php echo $item;?>"
	
	
  },
  function(data, status){
    alert($.trim(data));
	location.reload();
  });
}




</script>

  

</body>

</html>