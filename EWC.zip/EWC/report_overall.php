<?php
if (!isset($_COOKIE["user_id"])) {
    header("Location: login.php?redirect=" . urlencode($_SERVER['REQUEST_URI']));
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
<link href="multi/searchableOptionList.css" rel="stylesheet">
<?php
include "header_include.php";
include "db_config.php";

$from_date = isset($_POST["from_date"]) ? $_POST["from_date"] : date('d-m-Y');
$to_date   = isset($_POST["to_date"]) ? $_POST["to_date"] : date('d-m-Y');
$shop_param = isset($_POST["shop"]) ? $_POST["shop"] : "";
?>
</head>

<body id="page-top">

<div id="wrapper">

<?php include "sidemenu.php"; ?>

<div id="content-wrapper" class="d-flex flex-column">

<div id="content">

<?php include "topmenu.php"; ?>

<div class="container-fluid">

<div class="row">
<div class="col-md-12">

<form action="#" method="post">
<table class="table table-striped">
<tr>

<td>
From Date<br>
<input type="text" name="from_date" id="from_date"
value="<?php echo $from_date; ?>"
class="form-control" autocomplete="off">
</td>

<td>
To Date<br>
<input type="text" name="to_date" id="to_date"
value="<?php echo $to_date; ?>"
class="form-control" autocomplete="off">
</td>

<td>
Shop<br>
<select class="form-control" name="shop">
<option value="">--All Shops--</option>

<?php
$sql_shop = "SELECT shop_id,shop_name FROM shop ORDER BY shop_name";
$res_shop = $conn->query($sql_shop);

while($row_shop = $res_shop->fetch_assoc())
{
$sel = ($shop_param==$row_shop["shop_id"]) ? "selected" : "";
?>

<option value="<?php echo strtoupper(explode(' ', trim($row_shop["shop_name"]))[0]); ?>" <?php echo $sel; ?>>
    <?php echo $row_shop["shop_name"]; ?>
</option>
<?php
}
?>

</select>
</td>

<td>
<br>
<input type="submit" class="btn btn-primary btn-sm" value="Search">
</td>

<td>
<br>
<button class="btn btn-success btn-sm" type="button" onclick="print_table()">Excel</button>
</td>

</tr>
</table>
</form>

<?php


$sql = "

SELECT 
    x.shop_id AS shop_name,

    IFNULL(p.CASH,0)   AS CASH,
    IFNULL(p.CREDIT,0) AS CREDIT,
    IFNULL(p.BANK,0)   AS BANK,

    IFNULL(e.ECASH,0)   AS ECASH,
    IFNULL(e.ECREDIT,0) AS ECREDIT,
    IFNULL(e.EBANK,0)   AS EBANK,

    (IFNULL(p.CASH,0)   - IFNULL(e.ECASH,0))   AS NET_CASH,
    (IFNULL(p.CREDIT,0) - IFNULL(e.ECREDIT,0)) AS NET_CREDIT,
    (IFNULL(p.BANK,0)   - IFNULL(e.EBANK,0))   AS NET_BANK,

    (
        IFNULL(p.CASH,0) +
        IFNULL(p.CREDIT,0) +
        IFNULL(p.BANK,0)
        -
        IFNULL(e.ECASH,0) -
        IFNULL(e.ECREDIT,0) -
        IFNULL(e.EBANK,0)
    ) AS TOTAL_NET_INCOME

FROM
(
    SELECT shop_id
    FROM payments
    WHERE payment_date BETWEEN STR_TO_DATE('$from_date','%d-%m-%Y')
    AND STR_TO_DATE('$to_date','%d-%m-%Y') and active_status = 'A'

    UNION

    SELECT
    CASE shop_id
    WHEN '1000002' THEN 'SIRASAPALLI'
    WHEN '1000003' THEN 'GAJUWAKA'
    ELSE shop_id
    END AS shop_id
    FROM expenditure
    WHERE date BETWEEN STR_TO_DATE('$from_date','%d-%m-%Y')
    AND STR_TO_DATE('$to_date','%d-%m-%Y')
) x

LEFT JOIN
(
    SELECT shop_id,

        SUM(CASE WHEN mode='CASH' THEN amount ELSE 0 END) CASH,
        SUM(CASE WHEN mode='CREDIT' THEN amount ELSE 0 END) CREDIT,
        SUM(CASE WHEN mode IN ('BANK','UPI') THEN amount ELSE 0 END) BANK

    FROM payments
    WHERE payment_date BETWEEN STR_TO_DATE('$from_date','%d-%m-%Y')
    AND STR_TO_DATE('$to_date','%d-%m-%Y') and active_status = 'A'

    GROUP BY shop_id
) p
ON x.shop_id = p.shop_id

LEFT JOIN
(
    SELECT
    CASE shop_id
        WHEN '1000002' THEN 'SIRASAPALLI'
        WHEN '1000003' THEN 'GAJUWAKA'
        ELSE shop_id
    END AS shop_id,

    SUM(CASE WHEN paytype_id='1000003' THEN amount ELSE 0 END) AS ECASH,
    SUM(CASE WHEN paytype_id='1000005' THEN amount ELSE 0 END) AS ECREDIT,
    SUM(CASE WHEN paytype_id='1000002' THEN amount ELSE 0 END) AS EBANK

FROM expenditure

WHERE `date` BETWEEN STR_TO_DATE('$from_date','%d-%m-%Y')
AND STR_TO_DATE('$to_date','%d-%m-%Y')

GROUP BY shop_id
) e
ON x.shop_id = e.shop_id

WHERE ('$shop_param'='' OR x.shop_id='$shop_param')

ORDER BY x.shop_id

";

$result = $conn->query($sql);

$gt = array_fill(0,10,0);

?>

<table class="table table-striped table-bordered"
id="report_table"
border="1"
style="width:100%;font-size:75%;font-weight:bold;text-transform:uppercase">

<thead>

<tr style="background-color:#f0f0f0 !important;">

<td rowspan="2"
style="color:#000 !important;font-weight:900 !important;">
</td>

<td colspan="3"
style="color:#000 !important;font-weight:900 !important;">
INCOME
</td>

<td colspan="3"
style="color:#000 !important;font-weight:900 !important;">
EXPENDITURE
</td>

<td colspan="3"
style="color:#000 !important;font-weight:900 !important;">
NET INCOME
</td>

<td rowspan="2"
style="color:#000 !important;font-weight:900 !important;">
TOTAL NET INCOME
</td>

</tr>

<tr style="background-color:#f0f0f0 !important;">

<td style="color:#000 !important;font-weight:900 !important;">CASH</td>
<td style="color:#000 !important;font-weight:900 !important;">CREDIT</td>
<td style="color:#000 !important;font-weight:900 !important;">BANK</td>

<td style="color:#000 !important;font-weight:900 !important;">CASH</td>
<td style="color:#000 !important;font-weight:900 !important;">CREDIT</td>
<td style="color:#000 !important;font-weight:900 !important;">BANK</td>

<td style="color:#000 !important;font-weight:900 !important;">CASH</td>
<td style="color:#000 !important;font-weight:900 !important;">CREDIT</td>
<td style="color:#000 !important;font-weight:900 !important;">BANK</td>

</tr>

</thead>
<tbody>

<?php while($row = $result->fetch_assoc()) { ?>

<tr>

<td><?php echo $row["shop_name"]; ?></td>

<td><?php echo $row["CASH"]; $gt[0]+=$row["CASH"]; ?></td>
<td><?php echo $row["CREDIT"]; $gt[1]+=$row["CREDIT"]; ?></td>
<td><?php echo $row["BANK"]; $gt[2]+=$row["BANK"]; ?></td>

<td><?php echo $row["ECASH"]; $gt[3]+=$row["ECASH"]; ?></td>
<td><?php echo $row["ECREDIT"]; $gt[4]+=$row["ECREDIT"]; ?></td>
<td><?php echo $row["EBANK"]; $gt[5]+=$row["EBANK"]; ?></td>

<td><?php echo $row["NET_CASH"]; $gt[6]+=$row["NET_CASH"]; ?></td>
<td><?php echo $row["NET_CREDIT"]; $gt[7]+=$row["NET_CREDIT"]; ?></td>
<td><?php echo $row["NET_BANK"]; $gt[8]+=$row["NET_BANK"]; ?></td>

<td><?php echo $row["TOTAL_NET_INCOME"]; $gt[9]+=$row["TOTAL_NET_INCOME"]; ?></td>

</tr>

<?php } ?>

<tr style="background:#e8e8e8;font-weight:bold;">

<td>Total</td>

<?php
for($i=0;$i<10;$i++)
{
echo "<td>".$gt[$i]."</td>";
}
?>

</tr>

</tbody>
</table>

</div>
</div>

</div>
</div>

<?php include "footer.php"; ?>

</div>
</div>

<?php include "modals.php"; ?>
<?php include "footer_include.php"; ?>

<script src="js/jquery-3.5.1.min.js"></script>
<script src="js/jquery-ui.min.js"></script>

<script>
$(function(){
$("#from_date").datepicker({dateFormat:"dd-mm-yy"});
$("#to_date").datepicker({dateFormat:"dd-mm-yy"});
});
</script>

<script src="js/tableToExcel.js"></script>

<script>
function print_table()
{
TableToExcel.convert(document.getElementById("report_table"));
}
</script>

</body>
</html>
```
